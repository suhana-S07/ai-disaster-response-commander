"""
AI Disaster Response Commander — Strands Agent

This module creates a real Strands Agent instance that powers the AI reasoning
for the disaster response simulation. The agent handles:

  - Disaster analysis
  - Victim prioritization
  - Response planning
  - Replanning after resource failures

If live AWS/Bedrock credentials are unavailable, a clearly separated DEMO
FALLBACK kicks in so the simulation remains fully usable. The demo fallback
is never presented as a real AI model response.

Usage:
    from agents.disaster_commander import DisasterCommanderAgent

    agent = DisasterCommanderAgent()
    result = agent.prioritize_victims(victims_data)
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Strands Agent import
# ---------------------------------------------------------------------------

try:
    from strands import Agent  # type: ignore
    from strands.models import BedrockModel  # type: ignore

    STRANDS_AVAILABLE = True
except ImportError:
    # Strands SDK not installed — fall back to demo mode
    STRANDS_AVAILABLE = False


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class VictimData:
    id: str
    name: str
    condition: str
    urgency: int
    zone: str
    assessment_outcome: str = "PENDING"
    visual_observations: list[str] = field(default_factory=list)
    reported_symptoms: list[str] = field(default_factory=list)
    can_move: bool = True
    people_count: int = 1
    immediate_danger: str = ""
    food_water_needed: bool = False


@dataclass
class ResourceData:
    drones: list[dict[str, Any]]
    teams: list[dict[str, Any]]
    emergency_kits: int


# ---------------------------------------------------------------------------
# System prompt for the Strands Agent
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are the AI Disaster Response Commander for a simulated flood disaster in Green Valley.

Your responsibilities:
1. Analyze the disaster situation and victim assessments.
2. Prioritize victims based on urgency, visual risk, reported information, and environmental danger.
3. Generate response plans with resource assignments (drones, rescue teams, emergency kits).
4. Replan when resources fail.

CRITICAL RULES:
- Your assessments are RESPONSE PRIORITIES, not medical diagnoses.
- You cannot medically diagnose injuries from visual observations alone.
- Use "HIGH VISUAL RISK", "POSSIBLE DISTRESS", or "PERSON APPEARS UNRESPONSIVE" for visual assessments.
- Always include "HUMAN ASSESSMENT REQUIRED" for high-risk or unresponsive victims.
- Every decision must include a clear, explainable reason.
- Resource assignments must consider availability and proximity.

Output structured JSON for each reasoning task.
"""


# ---------------------------------------------------------------------------
# Disaster Commander Agent
# ---------------------------------------------------------------------------


class DisasterCommanderAgent:
    """
    Wraps a Strands Agent for disaster response reasoning.

    When Strands + AWS Bedrock credentials are available, real AI reasoning
    is used (STRANDS AGENT MODE). Otherwise, a deterministic demo fallback
    provides the same structured output (DEMO SIMULATION MODE).
    """

    def __init__(self) -> None:
        self.mode: str = "DEMO_SIMULATION"
        self.agent: Agent | None = None

        if STRANDS_AVAILABLE:
            try:
                # Attempt to create a Bedrock-backed Strands Agent
                model = BedrockModel(
                    model_id=os.environ.get("STRANDS_MODEL_ID", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
                    region_name=os.environ.get("AWS_REGION", "us-east-1"),
                )
                self.agent = Agent(model=model, system_prompt=SYSTEM_PROMPT)
                self.mode = "STRANDS_AGENT"
            except Exception:
                # Credentials not available — stay in demo mode
                self.agent = None
                self.mode = "DEMO_SIMULATION"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_disaster(self, disaster_info: dict[str, Any]) -> dict[str, Any]:
        """Analyze the overall disaster situation."""
        if self.agent:
            prompt = self._build_analysis_prompt(disaster_info)
            response = self.agent(prompt)
            return self._parse_response(response, fallback=lambda: self._demo_analyze_disaster(disaster_info))
        return self._demo_analyze_disaster(disaster_info)

    def prioritize_victims(self, victims: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Prioritize victims based on assessment data."""
        if self.agent:
            prompt = self._build_prioritization_prompt(victims)
            response = self.agent(prompt)
            return self._parse_response(response, fallback=lambda: self._demo_prioritize_victims(victims))
        return self._demo_prioritize_victims(victims)

    def generate_response_plan(
        self,
        victims: list[dict[str, Any]],
        resources: ResourceData,
    ) -> dict[str, Any]:
        """Generate a response plan with resource assignments."""
        if self.agent:
            prompt = self._build_plan_prompt(victims, resources)
            response = self.agent(prompt)
            return self._parse_response(response, fallback=lambda: self._demo_generate_plan(victims, resources))
        return self._demo_generate_plan(victims, resources)

    def replan(
        self,
        victims: list[dict[str, Any]],
        resources: ResourceData,
        failed_drone_id: str,
    ) -> dict[str, Any]:
        """Replan after a resource failure."""
        if self.agent:
            prompt = self._build_replan_prompt(victims, resources, failed_drone_id)
            response = self.agent(prompt)
            return self._parse_response(response, fallback=lambda: self._demo_replan(victims, resources, failed_drone_id))
        return self._demo_replan(victims, resources, failed_drone_id)

    # ------------------------------------------------------------------
    # Prompt builders
    # ------------------------------------------------------------------

    def _build_analysis_prompt(self, disaster_info: dict[str, Any]) -> str:
        return json.dumps({
            "task": "analyze_disaster",
            "disaster": disaster_info,
            "instructions": "Provide a structured analysis of the disaster situation including severity assessment, risk factors, and recommended initial actions.",
        })

    def _build_prioritization_prompt(self, victims: list[dict[str, Any]]) -> str:
        return json.dumps({
            "task": "prioritize_victims",
            "victims": victims,
            "instructions": "For each victim, assign a priority level (CRITICAL/HIGH/MEDIUM/LOW), risk level, and provide a clear reason. These are response priorities, not medical diagnoses.",
        })

    def _build_plan_prompt(self, victims: list[dict[str, Any]], resources: ResourceData) -> str:
        return json.dumps({
            "task": "generate_response_plan",
            "victims": victims,
            "available_drones": resources.drones,
            "available_teams": resources.teams,
            "emergency_kits": resources.emergency_kits,
            "instructions": "Assign drones, rescue teams, and emergency kits to victims. Include reasoning for each assignment.",
        })

    def _build_replan_prompt(self, victims: list[dict[str, Any]], resources: ResourceData, failed_drone_id: str) -> str:
        return json.dumps({
            "task": "replan",
            "victims": victims,
            "available_drones": resources.drones,
            "available_teams": resources.teams,
            "emergency_kits": resources.emergency_kits,
            "failed_drone_id": failed_drone_id,
            "instructions": f"Drone {failed_drone_id} has become unavailable. Recalculate the response plan and reassign resources. Explain why the new assignments were selected.",
        })

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_response(self, response: Any, fallback: Any) -> Any:
        try:
            if isinstance(response, str):
                return json.loads(response)
            return response
        except (json.JSONDecodeError, TypeError):
            return fallback()

    # ------------------------------------------------------------------
    # Demo fallback implementations (deterministic, no AI)
    # ------------------------------------------------------------------

    def _demo_analyze_disaster(self, disaster_info: dict[str, Any]) -> dict[str, Any]:
        return {
            "mode": "DEMO_SIMULATION",
            "analysis": {
                "type": disaster_info.get("type", "Flood"),
                "location": disaster_info.get("location", "Green Valley"),
                "severity": disaster_info.get("severity", "High"),
                "weather": disaster_info.get("weather", "Heavy rainfall"),
                "risk_factors": [
                    "Rising floodwater levels",
                    "Trapped civilians in multiple zones",
                    "Limited drone and rescue team resources",
                ],
                "recommended_actions": [
                    "Deploy drones for immediate aerial scan of all zones",
                    "Prioritize victims in highest-risk zones",
                    "Prepare rescue teams for deployment",
                ],
            },
        }

    def _demo_prioritize_victims(self, victims: list[dict[str, Any]]) -> list[dict[str, Any]]:
        results = []
        for v in victims:
            urgency = v.get("urgency", 5)
            outcome = v.get("assessment_outcome", "PENDING")

            if outcome == "VISUAL_RISK":
                priority = "CRITICAL"
                risk = "CRITICAL"
                reason = f"{v['id']} appears unresponsive and is located in a high-risk flood zone. Visual indicators suggest trapped and motionless. Human assessment required."
            elif outcome == "UNRESPONSIVE":
                priority = "CRITICAL"
                risk = "CRITICAL"
                reason = f"{v['id']} is unresponsive. Drone attempted communication with no response. Human assessment required."
            elif outcome == "RESPONSIVE":
                symptoms = v.get("reported_symptoms", [])
                can_move = v.get("can_move", True)
                if urgency >= 9 and (len(symptoms) > 0 or not can_move):
                    priority = "CRITICAL"
                    risk = "CRITICAL"
                    reason = f"{v['id']} reports severe symptoms and inability to stand. Multiple people present. No food or water."
                elif urgency >= 6:
                    priority = "HIGH"
                    risk = "HIGH"
                    reason = f"{v['id']} reports need for food and water. Rising water in area."
                elif urgency >= 5:
                    priority = "MEDIUM"
                    risk = "MODERATE"
                    reason = f"{v['id']} reports minor injury but is mobile and on higher ground."
                else:
                    priority = "LOW"
                    risk = "LOW"
                    reason = f"{v['id']} is safe, mobile, and stranded but not in immediate danger."
            else:
                priority = "LOW"
                risk = "LOW"
                reason = f"{v['id']} pending assessment."

            results.append({
                "id": v["id"],
                "priority": priority,
                "risk_level": risk,
                "reason": reason,
                "recommended_action": self._demo_recommended_action(priority, outcome),
            })
        return results

    def _demo_recommended_action(self, priority: str, outcome: str) -> str:
        if priority == "CRITICAL" and outcome == "VISUAL_RISK":
            return "Immediate rescue team dispatch required. Human assessment required on site."
        elif priority == "CRITICAL":
            return "Dispatch rescue team with emergency kit. Victim is responsive but in severe distress."
        elif priority == "HIGH":
            return "Dispatch drone with emergency kit and rescue team for evacuation."
        elif priority == "MEDIUM":
            return "Schedule rescue team pickup when higher-priority rescues are underway."
        else:
            return "Low-priority evacuation when resources permit."

    def _demo_generate_plan(self, victims: list[dict[str, Any]], resources: ResourceData) -> dict[str, Any]:
        priority_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        sorted_victims = sorted(victims, key=lambda v: priority_order.get(v.get("priority", "LOW"), 3))

        available_drones = [d for d in resources.drones if d.get("status") == "AVAILABLE"]
        available_teams = [t for t in resources.teams if t.get("status") == "AVAILABLE"]
        kits = resources.emergency_kits

        items = []
        for v in sorted_victims:
            drone = available_drones[0] if available_drones else None
            if drone:
                available_drones.remove(drone)
            team = available_teams[0] if available_teams else None
            if team:
                available_teams.remove(team)

            needs_kit = v.get("priority") in ("CRITICAL", "HIGH") or v.get("food_water_needed", False)
            kit_assigned = needs_kit and kits > 0
            if kit_assigned:
                kits -= 1

            items.append({
                "victim_id": v["id"],
                "drone_id": drone["id"] if drone else None,
                "team_id": team["id"] if team else None,
                "kit_assigned": kit_assigned,
                "priority": v.get("priority", "LOW"),
                "reason": f"{v['id']} has {v.get('priority', 'LOW').lower()} response priority. {v.get('reason', '')}",
                "action": v.get("recommended_action", ""),
            })

        return {
            "mode": "DEMO_SIMULATION",
            "items": items,
        }

    def _demo_replan(self, victims: list[dict[str, Any]], resources: ResourceData, failed_drone_id: str) -> dict[str, Any]:
        # Find affected victim
        affected = next((v for v in victims if v.get("assigned_drone") == failed_drone_id), None)
        available_drone = next((d for d in resources.drones if d.get("status") == "AVAILABLE" and not d.get("assigned_victim")), None)

        if affected and available_drone:
            reason = f"{failed_drone_id} became unavailable; {available_drone['id']} is the nearest available simulated drone/resource. Reassigning {available_drone['id']} -> {affected['id']}."
        elif affected:
            reason = f"{failed_drone_id} became unavailable and no replacement drone is available. {affected['id']} will rely on rescue team only."
        else:
            reason = f"{failed_drone_id} became unavailable. No affected assignments found."

        # Regenerate plan without the failed drone
        clean_drones = [d for d in resources.drones if d.get("id") != failed_drone_id or d.get("status") != "OFFLINE"]
        clean_victims = [{**v, "assigned_drone": None if v.get("assigned_drone") == failed_drone_id else v.get("assigned_drone")} for v in victims]

        plan = self._demo_generate_plan(clean_victims, ResourceData(
            drones=clean_drones,
            teams=resources.teams,
            emergency_kits=resources.emergency_kits,
        ))

        return {
            "mode": "DEMO_SIMULATION",
            "reason": reason,
            "plan": plan,
        }
