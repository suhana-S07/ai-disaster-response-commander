"""
FastAPI server for the AI Disaster Response Commander.

Provides a clean API between the React frontend and the Python Strands Agent backend.

Endpoints:
  GET  /api/health          — Health check + agent mode
  POST /api/analyze         — Analyze disaster situation
  POST /api/prioritize      — Prioritize victims
  POST /api/plan             — Generate response plan
  POST /api/replan           — Replan after resource failure

Run:
  uvicorn api.server:app --reload --port 8000
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agents.disaster_commander import DisasterCommanderAgent, ResourceData

app = FastAPI(title="AI Disaster Response Commander API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

agent = DisasterCommanderAgent()


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class DisasterInfo(BaseModel):
    type: str
    location: str
    severity: str
    weather: str


class VictimInput(BaseModel):
    id: str
    name: str
    condition: str
    urgency: int
    zone: str
    assessment_outcome: str = "PENDING"
    visual_observations: list[str] = []
    reported_symptoms: list[str] = []
    can_move: bool = True
    people_count: int = 1
    immediate_danger: str = ""
    food_water_needed: bool = False
    priority: str = "LOW"
    reason: str = ""
    recommended_action: str = ""
    assigned_drone: str | None = None


class DroneInput(BaseModel):
    id: str
    battery: int
    status: str
    assigned_victim: str | None = None


class TeamInput(BaseModel):
    id: str
    status: str
    assigned_victim: str | None = None


class ResourceInput(BaseModel):
    drones: list[DroneInput]
    teams: list[TeamInput]
    emergency_kits: int


class AnalyzeRequest(BaseModel):
    disaster_info: DisasterInfo


class PrioritizeRequest(BaseModel):
    victims: list[VictimInput]


class PlanRequest(BaseModel):
    victims: list[VictimInput]
    resources: ResourceInput


class ReplanRequest(BaseModel):
    victims: list[VictimInput]
    resources: ResourceInput
    failed_drone_id: str


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "agent_mode": agent.mode,
        "strands_available": agent.agent is not None,
    }


@app.post("/api/analyze")
async def analyze_disaster(req: AnalyzeRequest):
    return agent.analyze_disaster(req.disaster_info.model_dump())


@app.post("/api/prioritize")
async def prioritize_victims(req: PrioritizeRequest):
    victims_data = [v.model_dump() for v in req.victims]
    return {"priorities": agent.prioritize_victims(victims_data)}


@app.post("/api/plan")
async def generate_plan(req: PlanRequest):
    victims_data = [v.model_dump() for v in req.victims]
    resources = ResourceData(
        drones=[d.model_dump() for d in req.resources.drones],
        teams=[t.model_dump() for t in req.resources.teams],
        emergency_kits=req.resources.emergency_kits,
    )
    return agent.generate_response_plan(victims_data, resources)


@app.post("/api/replan")
async def replan(req: ReplanRequest):
    victims_data = [v.model_dump() for v in req.victims]
    resources = ResourceData(
        drones=[d.model_dump() for d in req.resources.drones],
        teams=[t.model_dump() for t in req.resources.teams],
        emergency_kits=req.resources.emergency_kits,
    )
    return agent.replan(victims_data, resources, req.failed_drone_id)
