# AI Disaster Response Commander — Python Backend

## Overview

This backend provides the Strands Agents SDK integration for the AI Disaster
Response Commander. It exposes a FastAPI server that the React frontend can
call for AI reasoning tasks.

## Architecture

```
backend/
├── agents/
│   └── disaster_commander.py   # Strands Agent + demo fallback
├── api/
│   └── server.py               # FastAPI server
├── requirements.txt
└── README.md
```

## Strands Agent Integration

The `DisasterCommanderAgent` class creates a real Strands Agent instance:

```python
from strands import Agent
from strands.models import BedrockModel

model = BedrockModel(model_id="anthropic.claude-3-5-sonnet-20241022-v2:0")
agent = Agent(model=model, system_prompt=SYSTEM_PROMPT)
```

The agent handles:
- Disaster analysis
- Victim prioritization
- Response planning
- Replanning after resource failures

## Demo Fallback

If AWS/Bedrock credentials are unavailable, the agent automatically falls back
to a deterministic demo mode. The demo mode:

- Produces the same structured JSON output
- Is clearly labeled as `DEMO_SIMULATION` mode
- Is never presented as a real AI model response
- Requires no credentials to run

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check + agent mode |
| POST | `/api/analyze` | Analyze disaster situation |
| POST | `/api/prioritize` | Prioritize victims |
| POST | `/api/plan` | Generate response plan |
| POST | `/api/replan` | Replan after resource failure |

## Running the Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn api.server:app --reload --port 8000
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `AWS_REGION` | `us-east-1` | AWS region for Bedrock |
| `STRANDS_MODEL_ID` | `anthropic.claude-3-5-sonnet-20241022-v2:0` | Bedrock model ID |

If AWS credentials are not configured, the backend runs in DEMO SIMULATION MODE automatically.
