import { Play, FileText, CheckCircle2, RefreshCw, RotateCcw, Loader2 } from 'lucide-react';
import type { OperationStatus } from '@/types';

interface DemoControlProps {
  status: OperationStatus;
  onRunAnalysis: () => void;
  onGeneratePlan: () => void;
  onApprovePlan: () => void;
  onApproveReplan: () => void;
  onReset: () => void;
}

export function DemoControl({
  status,
  onRunAnalysis,
  onGeneratePlan,
  onApprovePlan,
  onApproveReplan,
  onReset,
}: DemoControlProps) {
  const showRun = status === 'STANDBY';
  const showGenerate = status === 'PLAN_READY';
  const showApprove = status === 'AWAITING_APPROVAL';
  const showReplanApprove = status === 'AWAITING_REPLAN_APPROVAL';
  const isActive = status === 'ANALYZING' || status === 'SIMULATION_ACTIVE' || status === 'REPLANNING';

  return (
    <div className="flex items-center gap-3 flex-wrap">
      {showRun && (
        <button
          onClick={onRunAnalysis}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 font-semibold text-sm hover:bg-cyan-500/30 transition-all"
        >
          <Play className="w-4 h-4" />
          RUN ANALYSIS
        </button>
      )}

      {showGenerate && (
        <button
          onClick={onGeneratePlan}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-500/20 border border-blue-500/50 text-blue-300 font-semibold text-sm hover:bg-blue-500/30 transition-all"
        >
          <FileText className="w-4 h-4" />
          GENERATE RESPONSE PLAN
        </button>
      )}

      {showApprove && (
        <button
          onClick={onApprovePlan}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-500/20 border border-amber-500/50 text-amber-300 font-semibold text-sm hover:bg-amber-500/30 transition-all"
        >
          <CheckCircle2 className="w-4 h-4" />
          APPROVE RESPONSE PLAN
        </button>
      )}

      {showReplanApprove && (
        <button
          onClick={onApproveReplan}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-500/20 border border-amber-500/50 text-amber-300 font-semibold text-sm hover:bg-amber-500/30 transition-all"
        >
          <CheckCircle2 className="w-4 h-4" />
          APPROVE UPDATED PLAN
        </button>
      )}

      {isActive && (
        <div className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-slate-800/50 border border-slate-700/50 text-slate-400 font-semibold text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          {status === 'REPLANNING' ? 'AI REPLANNING...' : status === 'ANALYZING' ? 'ANALYZING...' : 'SIMULATION ACTIVE...'}
        </div>
      )}

      {status !== 'STANDBY' && (
        <button
          onClick={onReset}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-slate-800/50 border border-slate-700/50 text-slate-400 font-semibold text-sm hover:bg-slate-700/50 transition-all ml-auto"
        >
          <RotateCcw className="w-4 h-4" />
          RESET
        </button>
      )}
    </div>
  );
}
