import { Shield, Radio, AlertTriangle } from 'lucide-react';
import type { OperationStatus, AgentMode } from '@/types';
import { StatusBadge } from './ui/StatusBadge';

interface HeaderProps {
  status: OperationStatus;
  agentMode: AgentMode;
}

export function Header({ status, agentMode }: HeaderProps) {
  return (
    <header className="border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30">
              <Shield className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-tight">
                AI DISASTER RESPONSE COMMANDER
              </h1>
              <p className="text-xs text-slate-400 leading-tight">
                Synthetic Ops · Green Valley · Control Room
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <Radio className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-semibold text-slate-300">
                {agentMode === 'STANDBY' ? 'AGENT: STANDBY' : agentMode === 'STRANDS_AGENT' ? 'STRANDS AGENT MODE' : 'DEMO SIMULATION MODE'}
              </span>
            </div>
            <StatusBadge status={status} />
          </div>
        </div>

        <div className="mt-2 flex items-start gap-2 px-3 py-2 rounded-lg bg-amber-500/5 border border-amber-500/20">
          <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-amber-200/80 leading-relaxed">
            <span className="font-semibold">SIMULATION DISCLAIMER:</span> This is a synthetic disaster-response simulation. AI assessments are decision-support recommendations and are not medical diagnoses. Human responders must verify victim conditions before real-world action. Drone and rescue operations shown are simulated.
          </p>
        </div>
      </div>
    </header>
  );
}
