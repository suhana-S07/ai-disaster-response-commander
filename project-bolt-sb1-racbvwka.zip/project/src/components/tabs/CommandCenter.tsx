import { CloudRain, MapPin, Thermometer, Wind } from 'lucide-react';
import type { Victim, Drone, RescueTeam, Alert, OperationStatus } from '@/types';
import { DisasterMap } from '@/components/DisasterMap';
import { AlertPanel } from '@/components/AlertPanel';
import { DISASTER_INFO } from '@/data/scenario';

interface CommandCenterProps {
  victims: Victim[];
  drones: Drone[];
  teams: RescueTeam[];
  alerts: Alert[];
  status: OperationStatus;
  scanProgress: number;
}

export function CommandCenter({ victims, drones, teams, alerts, status, scanProgress }: CommandCenterProps) {
  const availableDrones = drones.filter((d) => d.status !== 'OFFLINE').length;
  const availableTeams = teams.filter((t) => t.status === 'AVAILABLE').length;
  const criticalVictims = victims.filter((v) => v.priority === 'CRITICAL').length;
  const rescuedVictims = victims.filter((v) => v.status === 'RESCUED').length;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 space-y-4">
        {/* Disaster Overview */}
        <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm p-4">
          <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <CloudRain className="w-4 h-4 text-blue-400" />
            Disaster Overview
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
              <p className="text-xs text-slate-500 uppercase">Type</p>
              <p className="text-sm font-bold text-blue-400 mt-1">{DISASTER_INFO.type}</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
              <p className="text-xs text-slate-500 uppercase">Location</p>
              <p className="text-sm font-bold text-white mt-1">{DISASTER_INFO.location}</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
              <p className="text-xs text-slate-500 uppercase">Severity</p>
              <p className="text-sm font-bold text-red-400 mt-1">{DISASTER_INFO.severity}</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
              <p className="text-xs text-slate-500 uppercase">Weather</p>
              <p className="text-sm font-bold text-cyan-400 mt-1">{DISASTER_INFO.weather}</p>
            </div>
          </div>
        </div>

        <DisasterMap victims={victims} drones={drones} teams={teams} />

        {/* Resource Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="rounded-lg p-3 bg-slate-900/50 border border-slate-700/50">
            <p className="text-xs text-slate-500 uppercase">Drones Active</p>
            <p className="text-lg font-bold text-cyan-400 mt-1">{availableDrones}/{drones.length}</p>
          </div>
          <div className="rounded-lg p-3 bg-slate-900/50 border border-slate-700/50">
            <p className="text-xs text-slate-500 uppercase">Teams Available</p>
            <p className="text-lg font-bold text-orange-400 mt-1">{availableTeams}/{teams.length}</p>
          </div>
          <div className="rounded-lg p-3 bg-slate-900/50 border border-slate-700/50">
            <p className="text-xs text-slate-500 uppercase">Critical Victims</p>
            <p className="text-lg font-bold text-red-400 mt-1">{criticalVictims}</p>
          </div>
          <div className="rounded-lg p-3 bg-slate-900/50 border border-slate-700/50">
            <p className="text-xs text-slate-500 uppercase">Rescued</p>
            <p className="text-lg font-bold text-emerald-400 mt-1">{rescuedVictims}/{victims.length}</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <AlertPanel alerts={alerts} />

        {scanProgress > 0 && scanProgress < 100 && (
          <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-4">
            <p className="text-xs text-slate-400 mb-2">Drone Scan Progress</p>
            <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500" style={{ width: `${scanProgress}%` }} />
            </div>
            <p className="text-xs text-cyan-400 mt-1.5">{scanProgress}%</p>
          </div>
        )}
      </div>
    </div>
  );
}
