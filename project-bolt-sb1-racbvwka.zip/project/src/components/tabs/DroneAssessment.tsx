import { ScanLine, Eye, AlertTriangle, Radio, CheckCircle2, Loader2 } from 'lucide-react';
import type { Victim, Drone } from '@/types';
import { RiskBadge } from '@/components/ui/StatusBadge';

interface DroneAssessmentProps {
  victims: Victim[];
  drones: Drone[];
}

export function DroneAssessment({ victims, drones }: DroneAssessmentProps) {
  return (
    <div className="space-y-3">
      {victims.map((v) => {
        const assignedDrone = drones.find((d) => d.id === v.assignedDrone);
        const isScanning = v.status === 'SCANNING';
        const isAssessed = v.status === 'ASSESSED' || v.status === 'COMMUNICATING' || v.status === 'PRIORITIZED' || v.status === 'ASSIGNED' || v.status === 'RESCUED';

        return (
          <div key={v.id} className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
              <ScanLine className={`w-4 h-4 ${isScanning ? 'text-cyan-400 animate-pulse' : 'text-slate-500'}`} />
              <span className="text-sm font-semibold text-white">{v.id} — {v.name}</span>
              <span className="text-xs text-slate-500">Zone {v.zone}</span>
              <div className="ml-auto flex items-center gap-2">
                {isScanning && (
                  <span className="flex items-center gap-1 text-xs text-cyan-400">
                    <Loader2 className="w-3 h-3 animate-spin" /> SCANNING
                  </span>
                )}
                {isAssessed && <RiskBadge level={v.riskLevel} />}
              </div>
            </div>

            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Drone Info */}
                <div>
                  <p className="text-xs text-slate-500 uppercase mb-2">Drone</p>
                  {assignedDrone ? (
                    <div className="space-y-1">
                      <p className="text-sm font-semibold text-cyan-400">{assignedDrone.id}</p>
                      <p className="text-xs text-slate-400">Battery: {assignedDrone.battery}%</p>
                      <p className="text-xs text-slate-400">Status: {assignedDrone.status}</p>
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500">{isScanning ? 'Scanning...' : 'Not assigned'}</p>
                  )}
                </div>

                {/* Visual Observations */}
                <div>
                  <p className="text-xs text-slate-500 uppercase mb-2 flex items-center gap-1">
                    <Eye className="w-3 h-3" /> Visual Observations
                  </p>
                  {v.visualObservations.length > 0 ? (
                    <ul className="space-y-1">
                      {v.visualObservations.map((obs, i) => (
                        <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                          <span className="text-cyan-400 mt-0.5">•</span>
                          {obs}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-slate-500">No observations yet</p>
                  )}
                </div>

                {/* Assessment Outcome */}
                <div>
                  <p className="text-xs text-slate-500 uppercase mb-2">Assessment</p>
                  {v.assessmentOutcome === 'VISUAL_RISK' && (
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-red-400">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        HIGH VISUAL RISK
                      </div>
                      <p className="text-xs text-red-300/80">Person appears unresponsive</p>
                      <p className="text-xs text-amber-400 font-semibold mt-1">HUMAN ASSESSMENT REQUIRED</p>
                    </div>
                  )}
                  {v.assessmentOutcome === 'RESPONSIVE' && (
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
                        <Radio className="w-3.5 h-3.5" />
                        RESPONSIVE
                      </div>
                      <p className="text-xs text-slate-300">Two-way communication established</p>
                    </div>
                  )}
                  {v.assessmentOutcome === 'UNRESPONSIVE' && (
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-red-400">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        UNRESPONSIVE
                      </div>
                      <p className="text-xs text-red-300/80">No response to communication</p>
                      <p className="text-xs text-amber-400 font-semibold mt-1">HUMAN ASSESSMENT REQUIRED</p>
                    </div>
                  )}
                  {v.assessmentOutcome === 'PENDING' && (
                    <p className="text-xs text-slate-500">Pending drone scan</p>
                  )}
                </div>
              </div>

              {isAssessed && v.assessmentOutcome === 'VISUAL_RISK' && (
                <div className="mt-3 p-2.5 rounded-lg bg-red-500/5 border border-red-500/20">
                  <p className="text-xs text-red-300/80 leading-relaxed">
                    <span className="font-semibold">Alert sent to rescue team:</span> {v.id} shows high visual risk indicators. Drone cannot medically diagnose condition. Human assessment required on site.
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
