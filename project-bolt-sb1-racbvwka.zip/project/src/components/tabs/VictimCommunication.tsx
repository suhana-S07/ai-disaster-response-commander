import { MessageSquare, Radio, User, Brain, Send } from 'lucide-react';
import type { Victim } from '@/types';
import { PriorityBadge } from '@/components/ui/StatusBadge';

interface VictimCommunicationProps {
  victims: Victim[];
}

const speakerConfig = {
  drone: { icon: Radio, color: 'text-cyan-400', bg: 'bg-cyan-500/10', label: 'Drone' },
  victim: { icon: User, color: 'text-orange-400', bg: 'bg-orange-500/10', label: 'Victim' },
  rescue: { icon: MessageSquare, color: 'text-blue-400', bg: 'bg-blue-500/10', label: 'Rescue Team' },
  ai: { icon: Brain, color: 'text-purple-400', bg: 'bg-purple-500/10', label: 'AI Commander' },
};

export function VictimCommunication({ victims }: VictimCommunicationProps) {
  const victimsWithConv = victims.filter((v) => v.conversation.length > 0);

  return (
    <div className="space-y-3">
      {victimsWithConv.length === 0 && (
        <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-8 text-center">
          <Radio className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No communications established yet. Run analysis to begin drone scans.</p>
        </div>
      )}

      {victimsWithConv.map((v) => (
        <div key={v.id} className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
            <Radio className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-semibold text-white">{v.id} — {v.name}</span>
            <span className="text-xs text-slate-500">Zone {v.zone}</span>
            <div className="ml-auto">
              <PriorityBadge level={v.priority} />
            </div>
          </div>

          <div className="p-4 space-y-3">
            {/* Conversation */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {v.conversation.map((msg, i) => {
                const config = speakerConfig[msg.speaker];
                const Icon = config.icon;
                const isAI = msg.speaker === 'ai';
                return (
                  <div key={i} className={`flex gap-2 ${isAI ? 'p-2.5 rounded-lg bg-purple-500/5 border border-purple-500/20' : ''}`}>
                    <div className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${config.bg}`}>
                      <Icon className={`w-3.5 h-3.5 ${config.color}`} />
                    </div>
                    <div className="flex-1">
                      <p className={`text-xs font-semibold ${config.color}`}>{config.label}</p>
                      <p className="text-sm text-slate-200 mt-0.5 leading-relaxed">{msg.text}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* AI Extracted Info */}
            {v.reportedSymptoms.length > 0 || v.peopleCount > 1 || v.foodWaterNeeded || !v.canMove ? (
              <div className="mt-3 p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
                <p className="text-xs font-semibold text-purple-400 mb-2 flex items-center gap-1.5">
                  <Brain className="w-3.5 h-3.5" /> AI-Extracted Response Information
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {v.reportedSymptoms.length > 0 && (
                    <div>
                      <p className="text-[10px] text-slate-500 uppercase">Reported Symptoms</p>
                      <p className="text-xs text-slate-300">{v.reportedSymptoms.join(', ')}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase">Can Move</p>
                    <p className="text-xs text-slate-300">{v.canMove ? 'Yes' : 'No'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase">People Count</p>
                    <p className="text-xs text-slate-300">{v.peopleCount}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase">Immediate Danger</p>
                    <p className="text-xs text-slate-300">{v.immediateDanger || 'None reported'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase">Food/Water Needed</p>
                    <p className="text-xs text-slate-300">{v.foodWaterNeeded ? 'Yes' : 'No'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-500 uppercase">Updated Priority</p>
                    <p className="text-xs text-slate-300 font-semibold">{v.priority}</p>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      ))}
    </div>
  );
}
