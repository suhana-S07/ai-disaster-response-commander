import { RefreshCw, AlertTriangle, ArrowRight, Brain, CheckCircle2, XCircle } from 'lucide-react';
import type { ResponsePlan, Victim, Drone, AgentMode } from '@/types';
import { PriorityBadge } from '@/components/ui/StatusBadge';

interface ReplanningProps {
  replan: { plan: ResponsePlan; reason: string } | null;
  victims: Victim[];
  drones: Drone[];
  agentMode: AgentMode;
  onApprove: () => void;
  showApprove: boolean;
  status: string;
}

export function Replanning({ replan, victims, drones, agentMode, onApprove, showApprove, status }: ReplanningProps) {
  if (!replan && status !== 'REPLANNING') {
    return (
      <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-8 text-center">
        <RefreshCw className="w-8 h-8 text-slate-600 mx-auto mb-2" />
        <p className="text-sm text-slate-500">No replanning triggered yet. Replanning occurs automatically when a resource fails during the simulation.</p>
      </div>
    );
  }

  const failedDrone = drones.find((d) => d.status === 'OFFLINE');
  const affectedVictim = victims.find((v) => v.id === 'V001');

  return (
    <div className="space-y-3">
      {/* Resource Failure Alert */}
      <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-4">
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-red-400 animate-pulse" />
          <div>
            <p className="text-sm font-bold text-red-400">RESOURCE FAILURE</p>
            <p className="text-xs text-slate-400 mt-0.5">D001 — OFFLINE</p>
          </div>
        </div>
      </div>

      {status === 'REPLANNING' && !replan && (
        <div className="rounded-xl border border-orange-500/30 bg-orange-500/5 p-4">
          <div className="flex items-center gap-3">
            <RefreshCw className="w-5 h-5 text-orange-400 animate-spin" />
            <div>
              <p className="text-sm font-bold text-orange-400">AI REPLANNING</p>
              <p className="text-xs text-slate-400 mt-0.5">AI Commander is detecting affected assignments and recalculating the response plan...</p>
            </div>
          </div>
        </div>
      )}

      {replan && (
        <>
          {/* AI Reasoning */}
          <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/5 p-4">
            <div className="flex items-center gap-2 mb-2">
              <Brain className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-semibold text-white">AI Replanning Reasoning</h3>
              <span className="ml-auto text-xs text-slate-500">
                {agentMode === 'STRANDS_AGENT' ? 'STRANDS AGENT MODE' : 'DEMO SIMULATION MODE'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{replan.reason}</p>
          </div>

          {/* Before / After */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="rounded-xl border border-red-500/20 bg-slate-900/50 p-4">
              <div className="flex items-center gap-2 mb-3">
                <XCircle className="w-4 h-4 text-red-400" />
                <h4 className="text-sm font-semibold text-red-400">Original Assignment</h4>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2.5 rounded-lg bg-red-500/5 border border-red-500/20">
                  <span className="text-sm font-mono text-red-400">D001</span>
                  <ArrowRight className="w-3 h-3 text-slate-600" />
                  <span className="text-sm font-mono text-slate-400">V001</span>
                  <span className="ml-auto text-xs text-red-400">FAILED</span>
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-green-500/20 bg-slate-900/50 p-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <h4 className="text-sm font-semibold text-green-400">Updated Assignment</h4>
              </div>
              <div className="space-y-2">
                {replan.plan.items
                  .filter((item) => item.victimId === 'V001')
                  .map((item) => (
                    <div key={item.victimId} className="space-y-1.5">
                      <div className="flex items-center gap-2 p-2.5 rounded-lg bg-green-500/5 border border-green-500/20">
                        <span className="text-sm font-mono text-green-400">{item.droneId || 'Drone unavailable'}</span>
                        <ArrowRight className="w-3 h-3 text-slate-600" />
                        <span className="text-sm font-mono text-slate-300">{item.victimId}</span>
                        <span className="ml-auto text-xs text-green-400">REASSIGNED</span>
                      </div>
                      <div className="flex items-center gap-2 p-2.5 rounded-lg bg-orange-500/5 border border-orange-500/20">
                        <span className="text-sm font-mono text-orange-400">{item.teamId || 'Pending'}</span>
                        <ArrowRight className="w-3 h-3 text-slate-600" />
                        <span className="text-sm font-mono text-slate-300">{item.victimId}</span>
                        <span className="ml-auto text-xs text-orange-400">RESCUE TEAM</span>
                      </div>
                      {!item.droneId && (
                        <p className="text-xs text-amber-400 px-1">
                          D001 offline — no replacement drone available. V001 relies on rescue team {item.teamId || 'pending'} only.
                        </p>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          </div>

          {/* Updated Plan */}
          <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
              <h3 className="text-sm font-semibold text-white">Updated Response Plan</h3>
            </div>
            <div className="p-3 space-y-2">
              {replan.plan.items.map((item, idx) => (
                <div key={item.victimId} className="p-3 rounded-lg border border-slate-700/30 bg-slate-800/50">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs text-slate-500 font-mono">#{idx + 1}</span>
                    <span className="text-sm font-semibold text-white">{item.victimId}</span>
                    <div className="ml-auto">
                      <PriorityBadge level={item.priority} />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500">Drone: </span>
                      <span className={`font-semibold ${item.droneId ? 'text-cyan-400' : 'text-red-400'}`}>{item.droneId || 'Unavailable'}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Team: </span>
                      <span className={`font-semibold ${item.teamId ? 'text-orange-400' : 'text-slate-500'}`}>{item.teamId || 'Pending'}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Kit: </span>
                      <span className="text-green-400 font-semibold">{item.kitAssigned ? 'Yes' : 'No'}</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">{item.reason}</p>
                </div>
              ))}
            </div>
          </div>

          {showApprove && (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <p className="text-sm font-bold text-amber-400">UPDATED PLAN READY</p>
                  <p className="text-xs text-slate-400 mt-1">
                    Human-in-the-Loop: The response plan has materially changed. Human approval is required.
                  </p>
                </div>
                <button
                  onClick={onApprove}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-500/20 border border-amber-500/50 text-amber-300 font-semibold text-sm hover:bg-amber-500/30 transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  APPROVE UPDATED PLAN
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
