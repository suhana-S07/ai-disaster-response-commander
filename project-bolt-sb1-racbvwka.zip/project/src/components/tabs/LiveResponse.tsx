import { Activity, Radar as RadarIcon, Users, CheckCircle2, Loader2, Radio } from 'lucide-react';
import type { Victim, Drone, RescueTeam, SimulationLogEntry, AgentMode } from '@/types';

interface LiveResponseProps {
  victims: Victim[];
  drones: Drone[];
  teams: RescueTeam[];
  logs: SimulationLogEntry[];
  agentMode: AgentMode;
  rescueProgress: number;
}

export function LiveResponse({ victims, drones, teams, logs, agentMode, rescueProgress }: LiveResponseProps) {
  const activeLogs = logs.filter((l) => l.phase === 'EXECUTION' || l.phase === 'APPROVAL' || l.phase === 'COMPLETE');

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-green-500/30 bg-green-500/5 p-4 flex items-center gap-3">
        <Activity className="w-5 h-5 text-green-400 animate-pulse" />
        <div>
          <p className="text-sm font-bold text-green-400">SIMULATION ACTIVE</p>
          <p className="text-xs text-slate-400">Live rescue execution monitoring</p>
        </div>
        <span className="ml-auto text-xs text-slate-500">
          {agentMode === 'STRANDS_AGENT' ? 'STRANDS AGENT MODE' : 'DEMO SIMULATION MODE'}
        </span>
      </div>

      {rescueProgress > 0 && (
        <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-4">
          <p className="text-xs text-slate-400 mb-2">Overall Rescue Progress</p>
          <div className="h-3 rounded-full bg-slate-800 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-500" style={{ width: `${rescueProgress}%` }} />
          </div>
          <p className="text-xs text-green-400 mt-1.5">{rescueProgress}%</p>
        </div>
      )}

      {/* Drone Status */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30 flex items-center gap-2">
          <RadarIcon className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-white">Drone Status</h3>
        </div>
        <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-3">
          {drones.map((d) => (
            <div key={d.id} className={`p-3 rounded-lg border ${d.status === 'OFFLINE' ? 'border-red-500/30 bg-red-500/5' : 'border-slate-700/30 bg-slate-800/50'}`}>
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-cyan-400">{d.id}</span>
                <span className={`text-xs font-semibold ${d.status === 'OFFLINE' ? 'text-red-400' : d.status === 'AVAILABLE' ? 'text-slate-400' : 'text-green-400'}`}>
                  {d.status}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-slate-700/50 overflow-hidden">
                  <div className={`h-full ${d.battery > 50 ? 'bg-green-500' : d.battery > 20 ? 'bg-yellow-500' : 'bg-red-500'}`} style={{ width: `${d.battery}%` }} />
                </div>
                <span className="text-xs text-slate-400">{d.battery}%</span>
              </div>
              {d.assignedVictim && (
                <p className="text-xs text-slate-500 mt-1.5">Assigned: {d.assignedVictim}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Rescue Team Status */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30 flex items-center gap-2">
          <Users className="w-4 h-4 text-orange-400" />
          <h3 className="text-sm font-semibold text-white">Rescue Team Status</h3>
        </div>
        <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-3">
          {teams.map((t) => (
            <div key={t.id} className="p-3 rounded-lg border border-slate-700/30 bg-slate-800/50">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-orange-400">{t.id}</span>
                <span className={`text-xs font-semibold ${t.status === 'AVAILABLE' ? 'text-slate-400' : 'text-green-400'}`}>
                  {t.status}
                </span>
              </div>
              {t.assignedVictim && (
                <p className="text-xs text-slate-500 mt-1.5">Assigned: {t.assignedVictim}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Victim Status */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30 flex items-center gap-2">
          <Radio className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">Victim Status</h3>
        </div>
        <div className="p-3 space-y-2">
          {victims.map((v) => (
            <div key={v.id} className="p-3 rounded-lg border border-slate-700/30 bg-slate-800/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-white">{v.id} — {v.name}</span>
                <span className={`text-xs font-semibold ${v.status === 'RESCUED' ? 'text-emerald-400' : v.status === 'ASSIGNED' ? 'text-green-400' : v.status === 'SCANNING' ? 'text-cyan-400' : 'text-slate-400'}`}>
                  {v.status === 'RESCUED' ? (
                    <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> RESCUED</span>
                  ) : v.status === 'ASSIGNED' ? (
                    <span className="flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> IN PROGRESS</span>
                  ) : v.status}
                </span>
              </div>
              {v.rescueProgress > 0 && v.status !== 'RESCUED' && (
                <div className="h-1.5 rounded-full bg-slate-700/50 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-orange-500 to-green-500 transition-all duration-500" style={{ width: `${v.rescueProgress}%` }} />
                </div>
              )}
              {v.status === 'RESCUED' && (
                <p className="text-xs text-emerald-400 mt-1">Victim extracted to safety</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Execution Log */}
      {activeLogs.length > 0 && (
        <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 overflow-hidden">
          <div className="px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
            <h3 className="text-sm font-semibold text-white">Execution Log</h3>
          </div>
          <div className="p-3 max-h-[200px] overflow-y-auto space-y-1">
            {activeLogs.map((log) => (
              <div key={log.id} className="flex items-start gap-2 text-xs">
                <span className="text-slate-600 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</span>
                <span className="text-slate-300">{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
