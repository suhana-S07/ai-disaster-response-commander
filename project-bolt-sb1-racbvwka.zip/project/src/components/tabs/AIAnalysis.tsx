import { Brain, Lightbulb, MapPin, Activity, AlertTriangle } from 'lucide-react';
import type { Victim, AgentMode } from '@/types';
import { PriorityBadge, RiskBadge } from '@/components/ui/StatusBadge';

interface AIAnalysisProps {
  victims: Victim[];
  agentMode: AgentMode;
}

export function AIAnalysis({ victims, agentMode }: AIAnalysisProps) {
  const assessed = victims.filter((v) => v.assessmentOutcome !== 'PENDING');
  const sorted = [...assessed].sort((a, b) => {
    const order: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
    return order[a.priority] - order[b.priority];
  });

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-4">
        <div className="flex items-center gap-2 mb-3">
          <Brain className="w-5 h-5 text-cyan-400" />
          <h3 className="text-sm font-semibold text-white">AI Commander — Prioritization Analysis</h3>
          <span className="ml-auto text-xs text-slate-500">
            {agentMode === 'STRANDS_AGENT' ? 'STRANDS AGENT MODE' : agentMode === 'DEMO_SIMULATION' ? 'DEMO SIMULATION MODE' : 'STANDBY'}
          </span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          The AI Commander considers disaster severity, victim urgency, visual risk, victim-reported information, accessibility, environmental danger, available drones, rescue team availability, emergency kit availability, and resource failures. These are <span className="text-amber-400 font-semibold">response priorities</span>, not medical diagnoses.
        </p>
      </div>

      {sorted.length === 0 && (
        <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-8 text-center">
          <Brain className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No analysis yet. Run analysis to begin AI prioritization.</p>
        </div>
      )}

      {sorted.map((v) => (
        <div key={v.id} className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
            <span className="text-sm font-semibold text-white">{v.id} — {v.name}</span>
            <div className="ml-auto flex items-center gap-2">
              <PriorityBadge level={v.priority} />
              <RiskBadge level={v.riskLevel} />
            </div>
          </div>

          <div className="p-4 space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <p className="text-[10px] text-slate-500 uppercase flex items-center gap-1"><MapPin className="w-3 h-3" /> Location</p>
                <p className="text-xs text-slate-300 mt-0.5">Zone {v.zone}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-500 uppercase flex items-center gap-1"><Activity className="w-3 h-3" /> Urgency</p>
                <p className="text-xs text-slate-300 mt-0.5">{v.urgency}/10</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-500 uppercase">Assessment</p>
                <p className="text-xs text-slate-300 mt-0.5">{v.assessmentOutcome.replace(/_/g, ' ')}</p>
              </div>
              <div>
                <p className="text-[10px] text-slate-500 uppercase">People</p>
                <p className="text-xs text-slate-300 mt-0.5">{v.peopleCount}</p>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
              <p className="text-xs font-semibold text-cyan-400 mb-1 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> AI Reasoning
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">{v.priorityReason}</p>
            </div>

            <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
              <p className="text-xs font-semibold text-amber-400 mb-1 flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5" /> Recommended Action
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">{v.recommendedAction}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
