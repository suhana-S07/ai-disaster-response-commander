import { ClipboardList, Radar as RadarIcon, Users, Package, CheckCircle2, Brain } from 'lucide-react';
import type { ResponsePlan as ResponsePlanType, AgentMode } from '@/types';
import { PriorityBadge } from '@/components/ui/StatusBadge';

interface ResponsePlanProps {
  plan: ResponsePlanType | null;
  agentMode: AgentMode;
  onApprove: () => void;
  showApprove: boolean;
}

export function ResponsePlan({ plan, agentMode, onApprove, showApprove }: ResponsePlanProps) {
  if (!plan) {
    return (
      <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 p-8 text-center">
        <ClipboardList className="w-8 h-8 text-slate-600 mx-auto mb-2" />
        <p className="text-sm text-slate-500">No response plan generated yet. Run analysis and generate a plan.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/5 p-4">
        <div className="flex items-center gap-2 mb-2">
          <Brain className="w-5 h-5 text-cyan-400" />
          <h3 className="text-sm font-semibold text-white">AI Response Plan</h3>
          <span className="ml-auto text-xs text-slate-500">
            {agentMode === 'STRANDS_AGENT' ? 'STRANDS AGENT MODE' : 'DEMO SIMULATION MODE'}
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Generated at {new Date(plan.timestamp).toLocaleTimeString()} · {plan.items.length} assignments
        </p>
      </div>

      {plan.items.map((item, idx) => (
        <div key={item.victimId} className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
            <span className="text-xs text-slate-500 font-mono">#{idx + 1}</span>
            <span className="text-sm font-semibold text-white">{item.victimId}</span>
            <div className="ml-auto">
              <PriorityBadge level={item.priority} />
            </div>
          </div>

          <div className="p-4 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/30">
                <RadarIcon className="w-4 h-4 text-cyan-400" />
                <div>
                  <p className="text-[10px] text-slate-500 uppercase">Drone</p>
                  <p className={`text-sm font-semibold ${item.droneId ? 'text-cyan-400' : 'text-slate-500'}`}>{item.droneId || 'Not assigned'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/30">
                <Users className="w-4 h-4 text-orange-400" />
                <div>
                  <p className="text-[10px] text-slate-500 uppercase">Rescue Team</p>
                  <p className={`text-sm font-semibold ${item.teamId ? 'text-orange-400' : 'text-slate-500'}`}>{item.teamId || 'Not assigned'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/30">
                <Package className="w-4 h-4 text-green-400" />
                <div>
                  <p className="text-[10px] text-slate-500 uppercase">Emergency Kit</p>
                  <p className="text-sm font-semibold text-green-400">{item.kitAssigned ? 'Assigned' : 'Not required'}</p>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/30">
              <p className="text-xs font-semibold text-cyan-400 mb-1">Reasoning</p>
              <p className="text-xs text-slate-300 leading-relaxed">{item.reason}</p>
            </div>

            <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
              <p className="text-xs font-semibold text-amber-400 mb-1">Action</p>
              <p className="text-xs text-slate-300 leading-relaxed">{item.action}</p>
            </div>
          </div>
        </div>
      ))}

      {showApprove && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="text-sm font-bold text-amber-400">AI RESPONSE PLAN READY</p>
              <p className="text-xs text-slate-400 mt-1">
                Human-in-the-Loop: The simulation will not proceed without human approval.
              </p>
            </div>
            <button
              onClick={onApprove}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-500/20 border border-amber-500/50 text-amber-300 font-semibold text-sm hover:bg-amber-500/30 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              APPROVE RESPONSE PLAN
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
