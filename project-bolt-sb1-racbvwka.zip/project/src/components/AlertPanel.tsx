import { Bell, AlertTriangle, AlertCircle, Info, XCircle } from 'lucide-react';
import type { Alert } from '@/types';

const alertConfig = {
  high_visual_risk: { icon: AlertCircle, color: 'text-red-400', border: 'border-red-500/30', bg: 'bg-red-500/5' },
  unresponsive_victim: { icon: XCircle, color: 'text-red-400', border: 'border-red-500/30', bg: 'bg-red-500/5' },
  communication_received: { icon: Info, color: 'text-cyan-400', border: 'border-cyan-500/30', bg: 'bg-cyan-500/5' },
  resource_failure: { icon: AlertTriangle, color: 'text-orange-400', border: 'border-orange-500/30', bg: 'bg-orange-500/5' },
  replanning_required: { icon: AlertTriangle, color: 'text-amber-400', border: 'border-amber-500/30', bg: 'bg-amber-500/5' },
  human_approval_required: { icon: Bell, color: 'text-amber-400', border: 'border-amber-500/30', bg: 'bg-amber-500/5' },
  simulation_completed: { icon: Info, color: 'text-emerald-400', border: 'border-emerald-500/30', bg: 'bg-emerald-500/5' },
  info: { icon: Info, color: 'text-slate-400', border: 'border-slate-600/30', bg: 'bg-slate-800/30' },
};

export function AlertPanel({ alerts }: { alerts: Alert[] }) {
  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
        <Bell className="w-4 h-4 text-amber-400" />
        <h3 className="text-sm font-semibold text-white">Alert System</h3>
        <span className="ml-auto text-xs text-slate-500">{alerts.length} alerts</span>
      </div>
      <div className="max-h-[280px] overflow-y-auto p-3 space-y-2">
        {alerts.length === 0 && (
          <p className="text-sm text-slate-500 text-center py-4">No alerts</p>
        )}
        {alerts.map((alert) => {
          const config = alertConfig[alert.type] || alertConfig.info;
          const Icon = config.icon;
          return (
            <div
              key={alert.id}
              className={`rounded-lg p-3 border ${config.border} ${config.bg} transition-all`}
            >
              <div className="flex items-start gap-2">
                <Icon className={`w-4 h-4 ${config.color} flex-shrink-0 mt-0.5`} />
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-bold ${config.color} uppercase tracking-wide`}>
                    {alert.title}
                  </p>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {alert.message}
                  </p>
                  <p className="text-[10px] text-slate-600 mt-1">
                    {new Date(alert.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
