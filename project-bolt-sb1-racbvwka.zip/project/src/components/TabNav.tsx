import {
  LayoutDashboard,
  ScanLine,
  MessageSquare,
  Brain,
  ClipboardList,
  Activity,
  RefreshCw,
} from 'lucide-react';

interface TabNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  hasReplan: boolean;
}

const tabs = [
  { id: 'command', label: 'Command Center', icon: LayoutDashboard },
  { id: 'assessment', label: 'Drone Assessment', icon: ScanLine },
  { id: 'communication', label: 'Victim Communication', icon: MessageSquare },
  { id: 'analysis', label: 'AI Analysis', icon: Brain },
  { id: 'plan', label: 'Response Plan', icon: ClipboardList },
  { id: 'live', label: 'Live Response', icon: Activity },
  { id: 'replanning', label: 'Replanning', icon: RefreshCw },
];

export function TabNav({ activeTab, onTabChange, hasReplan }: TabNavProps) {
  return (
    <div className="flex gap-1 overflow-x-auto pb-px">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        const showBadge = tab.id === 'replanning' && hasReplan;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-t-lg text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${
              isActive
                ? 'text-cyan-400 border-cyan-400 bg-slate-800/50'
                : 'text-slate-400 border-transparent hover:text-slate-300 hover:bg-slate-800/30'
            }`}
          >
            <Icon className="w-4 h-4" />
            {tab.label}
            {showBadge && (
              <span className="w-2 h-2 rounded-full bg-orange-400 animate-pulse" />
            )}
          </button>
        );
      })}
    </div>
  );
}
