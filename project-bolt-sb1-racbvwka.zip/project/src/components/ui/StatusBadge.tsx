import type { PriorityLevel, RiskLevel, OperationStatus } from '@/types';

const priorityColors: Record<PriorityLevel, string> = {
  CRITICAL: 'bg-red-500/20 text-red-400 border-red-500/50',
  HIGH: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
  MEDIUM: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
  LOW: 'bg-green-500/20 text-green-400 border-green-500/50',
};

const riskColors: Record<RiskLevel, string> = {
  CRITICAL: 'bg-red-500/20 text-red-400 border-red-500/50',
  HIGH: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
  MODERATE: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
  LOW: 'bg-green-500/20 text-green-400 border-green-500/50',
};

const statusColors: Record<OperationStatus, string> = {
  STANDBY: 'bg-slate-500/20 text-slate-400 border-slate-500/50',
  ANALYZING: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
  PLAN_READY: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50',
  AWAITING_APPROVAL: 'bg-amber-500/20 text-amber-400 border-amber-500/50',
  SIMULATION_ACTIVE: 'bg-green-500/20 text-green-400 border-green-500/50',
  REPLANNING: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
  AWAITING_REPLAN_APPROVAL: 'bg-amber-500/20 text-amber-400 border-amber-500/50',
  COMPLETED: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
};

export function PriorityBadge({ level }: { level: PriorityLevel }) {
  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${priorityColors[level]}`}>
      {level}
    </span>
  );
}

export function RiskBadge({ level }: { level: RiskLevel }) {
  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${riskColors[level]}`}>
      {level}
    </span>
  );
}

export function StatusBadge({ status }: { status: OperationStatus }) {
  const isAnimated = status === 'ANALYZING' || status === 'SIMULATION_ACTIVE' || status === 'REPLANNING';
  return (
    <span className={`px-3 py-1 rounded-full text-xs font-bold border ${statusColors[status]} ${isAnimated ? 'animate-pulse' : ''}`}>
      {status.replace(/_/g, ' ')}
    </span>
  );
}
