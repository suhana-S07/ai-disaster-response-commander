import { Waves, AlertOctagon, Users, Package, Activity, Radar as RadarIcon } from 'lucide-react';
import type { OperationStatus } from '@/types';

interface StatusCardsProps {
  disasterType: string;
  severity: string;
  victimCount: number;
  availableResources: number;
  emergencyKits: number;
  status: OperationStatus;
}

export function StatusCards({
  disasterType,
  severity,
  victimCount,
  availableResources,
  emergencyKits,
  status,
}: StatusCardsProps) {
  const cards = [
    {
      label: 'Disaster',
      value: disasterType,
      icon: Waves,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10',
      border: 'border-blue-500/20',
    },
    {
      label: 'Severity',
      value: severity,
      icon: AlertOctagon,
      color: 'text-red-400',
      bg: 'bg-red-500/10',
      border: 'border-red-500/20',
    },
    {
      label: 'Victims',
      value: victimCount.toString(),
      icon: Users,
      color: 'text-orange-400',
      bg: 'bg-orange-500/10',
      border: 'border-orange-500/20',
    },
    {
      label: 'Available Resources',
      value: availableResources.toString(),
      icon: RadarIcon,
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/20',
    },
    {
      label: 'Emergency Kits',
      value: emergencyKits.toString(),
      icon: Package,
      color: 'text-green-400',
      bg: 'bg-green-500/10',
      border: 'border-green-500/20',
    },
    {
      label: 'Operation Status',
      value: status.replace(/_/g, ' '),
      icon: Activity,
      color: status === 'COMPLETED' ? 'text-emerald-400' : status === 'STANDBY' ? 'text-slate-400' : 'text-cyan-400',
      bg: status === 'COMPLETED' ? 'bg-emerald-500/10' : status === 'STANDBY' ? 'bg-slate-500/10' : 'bg-cyan-500/10',
      border: status === 'COMPLETED' ? 'border-emerald-500/20' : status === 'STANDBY' ? 'border-slate-500/20' : 'border-cyan-500/20',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <div
            key={card.label}
            className={`rounded-xl p-3 border ${card.border} ${card.bg} backdrop-blur-sm transition-all hover:scale-[1.02]`}
          >
            <div className="flex items-center gap-2 mb-1.5">
              <Icon className={`w-4 h-4 ${card.color}`} />
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wide">
                {card.label}
              </span>
            </div>
            <p className={`text-lg font-bold ${card.color}`}>
              {card.value}
            </p>
          </div>
        );
      })}
    </div>
  );
}
