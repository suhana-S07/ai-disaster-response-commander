import { MapPin, Radar as RadarIcon, Users, Crosshair } from 'lucide-react';
import type { Victim, Drone, RescueTeam } from '@/types';
import { ZONES, DRONE_BASE } from '@/data/scenario';

interface DisasterMapProps {
  victims: Victim[];
  drones: Drone[];
  teams: RescueTeam[];
}

const victimColors: Record<string, string> = {
  CRITICAL: 'text-red-400 bg-red-500/20 border-red-500/50',
  HIGH: 'text-orange-400 bg-orange-500/20 border-orange-500/50',
  MEDIUM: 'text-yellow-400 bg-yellow-500/20 border-yellow-500/50',
  LOW: 'text-green-400 bg-green-500/20 border-green-500/50',
};

export function DisasterMap({ victims, drones, teams }: DisasterMapProps) {
  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-sm overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-slate-700/50 bg-slate-800/30">
        <Crosshair className="w-4 h-4 text-cyan-400" />
        <h3 className="text-sm font-semibold text-white">Green Valley — Operational Area</h3>
        <span className="ml-auto text-xs text-slate-500">Synthetic Map</span>
      </div>
      <div className="relative aspect-[16/10] bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950/30 overflow-hidden">
        {/* Flood water overlay */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-blue-800/10 to-cyan-900/20" />
          <div className="absolute top-[10%] left-[5%] w-[60%] h-[50%] rounded-full bg-blue-500/10 blur-3xl" />
          <div className="absolute bottom-[5%] right-[10%] w-[50%] h-[40%] rounded-full bg-cyan-500/10 blur-3xl" />
        </div>

        {/* Grid lines */}
        <div className="absolute inset-0 opacity-10">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={`h${i}`} className="absolute left-0 right-0 border-t border-cyan-400/20" style={{ top: `${i * 10}%` }} />
          ))}
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={`v${i}`} className="absolute top-0 bottom-0 border-l border-cyan-400/20" style={{ left: `${i * 6.25}%` }} />
          ))}
        </div>

        {/* Zones */}
        {ZONES.map((zone) => (
          <div
            key={zone.id}
            className="absolute -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${zone.x}%`, top: `${zone.y}%` }}
          >
            <div className="w-16 h-16 rounded-full border border-cyan-500/20 bg-cyan-500/5 flex items-center justify-center">
              <span className="text-[10px] text-cyan-400/50 font-semibold">{zone.label}</span>
            </div>
          </div>
        ))}

        {/* Victims */}
        {victims.map((v) => {
          const zone = ZONES.find((z) => z.id === v.zone);
          if (!zone) return null;
          const colorClass = victimColors[v.priority] || victimColors.LOW;
          const isRescued = v.status === 'RESCUED';
          return (
            <div
              key={v.id}
              className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-500"
              style={{ left: `${zone.x}%`, top: `${zone.y}%` }}
            >
              <div className={`relative flex flex-col items-center`}>
                <div
                  className={`w-9 h-9 rounded-full border-2 flex items-center justify-center ${isRescued ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400' : colorClass} ${v.status === 'SCANNING' ? 'animate-ping' : ''}`}
                >
                  <Users className="w-4 h-4" />
                </div>
                <span className={`text-[10px] font-bold mt-0.5 ${isRescued ? 'text-emerald-400' : 'text-slate-300'}`}>
                  {v.id}
                </span>
                {v.priority === 'CRITICAL' && !isRescued && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
                )}
              </div>
            </div>
          );
        })}

        {/* Drones */}
        {drones.map((d, idx) => {
          const offset = idx === 0 ? -8 : 8;
          const pos = d.assignedVictim
            ? { x: ZONES.find((z) => z.id === victims.find((v) => v.id === d.assignedVictim)?.zone)?.x || 50, y: (ZONES.find((z) => z.id === victims.find((v) => v.id === d.assignedVictim)?.zone)?.y || 50) + offset }
            : DRONE_BASE;
          return (
            <div
              key={d.id}
              className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700"
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
            >
              <div className={`relative flex flex-col items-center ${d.status === 'OFFLINE' ? 'opacity-30' : ''}`}>
                <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${d.status === 'OFFLINE' ? 'bg-red-500/20 border-red-500/50 text-red-400' : d.status === 'SCANNING' || d.status === 'EN_ROUTE' || d.status === 'ON_SITE' ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-400' : 'bg-slate-700/50 border-slate-500/50 text-slate-400'}`}>
                  <RadarIcon className="w-4 h-4" />
                </div>
                <span className={`text-[10px] font-bold mt-0.5 ${d.status === 'OFFLINE' ? 'text-red-400' : 'text-cyan-400'}`}>
                  {d.id}
                </span>
              </div>
            </div>
          );
        })}

        {/* Rescue Teams */}
        {teams.map((t, idx) => {
          const assignedVictim = victims.find((v) => v.id === t.assignedVictim);
          const zone = assignedVictim ? ZONES.find((z) => z.id === assignedVictim.zone) : null;
          const pos = zone ? { x: zone.x + (idx === 0 ? 10 : -10), y: zone.y + 10 } : { x: 50, y: 85 };
          return (
            <div
              key={t.id}
              className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700"
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
            >
              <div className="relative flex flex-col items-center">
                <div className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center ${t.status === 'AVAILABLE' ? 'bg-slate-700/50 border-slate-500/50 text-slate-400' : 'bg-orange-500/20 border-orange-400/50 text-orange-400'}`}>
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                <span className={`text-[10px] font-bold mt-0.5 ${t.status === 'AVAILABLE' ? 'text-slate-400' : 'text-orange-400'}`}>
                  {t.id}
                </span>
              </div>
            </div>
          );
        })}

        {/* Legend */}
        <div className="absolute bottom-2 left-2 flex flex-wrap gap-2 text-[10px]">
          <div className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900/70 border border-slate-700/50">
            <Users className="w-3 h-3 text-orange-400" /> Victim
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900/70 border border-slate-700/50">
            <RadarIcon className="w-3 h-3 text-cyan-400" /> Drone
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900/70 border border-slate-700/50">
            <MapPin className="w-3 h-3 text-orange-400" /> Rescue Team
          </div>
        </div>
      </div>
    </div>
  );
}
