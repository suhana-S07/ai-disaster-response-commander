export type OperationStatus =
  | 'STANDBY'
  | 'ANALYZING'
  | 'PLAN_READY'
  | 'AWAITING_APPROVAL'
  | 'SIMULATION_ACTIVE'
  | 'REPLANNING'
  | 'AWAITING_REPLAN_APPROVAL'
  | 'COMPLETED';

export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export type PriorityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type DroneStatus = 'AVAILABLE' | 'SCANNING' | 'COMMUNICATING' | 'EN_ROUTE' | 'ON_SITE' | 'OFFLINE';

export type RescueTeamStatus = 'AVAILABLE' | 'EN_ROUTE' | 'ON_SITE' | 'RETURNING';

export type VictimStatus = 'PENDING' | 'SCANNING' | 'ASSESSED' | 'COMMUNICATING' | 'PRIORITIZED' | 'ASSIGNED' | 'RESCUED';

export type AssessmentOutcome = 'VISUAL_RISK' | 'RESPONSIVE' | 'UNRESPONSIVE' | 'PENDING';

export type AgentMode = 'STANDBY' | 'STRANDS_AGENT' | 'DEMO_SIMULATION';

export interface Victim {
  id: string;
  name: string;
  condition: string;
  urgency: number;
  zone: string;
  status: VictimStatus;
  assessmentOutcome: AssessmentOutcome;
  visualObservations: string[];
  riskLevel: RiskLevel;
  priority: PriorityLevel;
  priorityReason: string;
  recommendedAction: string;
  reportedSymptoms: string[];
  canMove: boolean;
  peopleCount: number;
  immediateDanger: string;
  foodWaterNeeded: boolean;
  conversation: ConversationMessage[];
  assignedDrone: string | null;
  assignedTeam: string | null;
  assignedKit: boolean;
  rescueProgress: number;
}

export interface ConversationMessage {
  speaker: 'drone' | 'victim' | 'rescue' | 'ai';
  text: string;
  timestamp: string;
}

export interface Drone {
  id: string;
  battery: number;
  status: DroneStatus;
  assignedVictim: string | null;
  position: { x: number; y: number };
}

export interface RescueTeam {
  id: string;
  status: RescueTeamStatus;
  assignedVictim: string | null;
}

export interface Alert {
  id: string;
  type: 'high_visual_risk' | 'unresponsive_victim' | 'communication_received' | 'resource_failure' | 'replanning_required' | 'human_approval_required' | 'simulation_completed' | 'info';
  title: string;
  message: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'critical';
}

export interface ResponsePlanItem {
  victimId: string;
  droneId: string | null;
  teamId: string | null;
  kitAssigned: boolean;
  priority: PriorityLevel;
  reason: string;
  action: string;
}

export interface ResponsePlan {
  items: ResponsePlanItem[];
  generatedBy: AgentMode;
  timestamp: string;
}

export interface SimulationLogEntry {
  id: string;
  timestamp: string;
  phase: string;
  message: string;
  agentMode: AgentMode;
}

export interface ZonePosition {
  id: string;
  label: string;
  x: number;
  y: number;
}
