import type {
  Victim,
  Drone,
  RescueTeam,
  Alert,
  ZonePosition,
} from '@/types';

export const DISASTER_INFO = {
  type: 'Flood',
  location: 'Green Valley',
  severity: 'High' as const,
  weather: 'Heavy rainfall',
};

export const ZONES: ZonePosition[] = [
  { id: 'A', label: 'Zone A', x: 20, y: 25 },
  { id: 'B', label: 'Zone B', x: 55, y: 20 },
  { id: 'C', label: 'Zone C', x: 78, y: 40 },
  { id: 'D', label: 'Zone D', x: 35, y: 60 },
  { id: 'E', label: 'Zone E', x: 68, y: 72 },
];

export const DRONE_BASE: { x: number; y: number } = { x: 50, y: 50 };

export const INITIAL_VICTIMS: Victim[] = [
  {
    id: 'V001',
    name: 'Person A',
    condition: 'Injured and trapped',
    urgency: 10,
    zone: 'A',
    status: 'PENDING',
    assessmentOutcome: 'PENDING',
    visualObservations: [],
    riskLevel: 'LOW',
    priority: 'LOW',
    priorityReason: '',
    recommendedAction: '',
    reportedSymptoms: [],
    canMove: false,
    peopleCount: 1,
    immediateDanger: '',
    foodWaterNeeded: false,
    conversation: [],
    assignedDrone: null,
    assignedTeam: null,
    assignedKit: false,
    rescueProgress: 0,
  },
  {
    id: 'V002',
    name: 'Person B',
    condition: 'Elderly and isolated',
    urgency: 9,
    zone: 'B',
    status: 'PENDING',
    assessmentOutcome: 'PENDING',
    visualObservations: [],
    riskLevel: 'LOW',
    priority: 'LOW',
    priorityReason: '',
    recommendedAction: '',
    reportedSymptoms: [],
    canMove: false,
    peopleCount: 1,
    immediateDanger: '',
    foodWaterNeeded: false,
    conversation: [],
    assignedDrone: null,
    assignedTeam: null,
    assignedKit: false,
    rescueProgress: 0,
  },
  {
    id: 'V003',
    name: 'Person C',
    condition: 'Needs food and water',
    urgency: 6,
    zone: 'C',
    status: 'PENDING',
    assessmentOutcome: 'PENDING',
    visualObservations: [],
    riskLevel: 'LOW',
    priority: 'LOW',
    priorityReason: '',
    recommendedAction: '',
    reportedSymptoms: [],
    canMove: true,
    peopleCount: 1,
    immediateDanger: '',
    foodWaterNeeded: true,
    conversation: [],
    assignedDrone: null,
    assignedTeam: null,
    assignedKit: false,
    rescueProgress: 0,
  },
  {
    id: 'V004',
    name: 'Person D',
    condition: 'Minor injury',
    urgency: 5,
    zone: 'D',
    status: 'PENDING',
    assessmentOutcome: 'PENDING',
    visualObservations: [],
    riskLevel: 'LOW',
    priority: 'LOW',
    priorityReason: '',
    recommendedAction: '',
    reportedSymptoms: [],
    canMove: true,
    peopleCount: 1,
    immediateDanger: '',
    foodWaterNeeded: false,
    conversation: [],
    assignedDrone: null,
    assignedTeam: null,
    assignedKit: false,
    rescueProgress: 0,
  },
  {
    id: 'V005',
    name: 'Person E',
    condition: 'Safe but stranded',
    urgency: 3,
    zone: 'E',
    status: 'PENDING',
    assessmentOutcome: 'PENDING',
    visualObservations: [],
    riskLevel: 'LOW',
    priority: 'LOW',
    priorityReason: '',
    recommendedAction: '',
    reportedSymptoms: [],
    canMove: true,
    peopleCount: 1,
    immediateDanger: '',
    foodWaterNeeded: false,
    conversation: [],
    assignedDrone: null,
    assignedTeam: null,
    assignedKit: false,
    rescueProgress: 0,
  },
];

export const INITIAL_DRONES: Drone[] = [
  {
    id: 'D001',
    battery: 92,
    status: 'AVAILABLE',
    assignedVictim: null,
    position: { ...DRONE_BASE },
  },
  {
    id: 'D002',
    battery: 76,
    status: 'AVAILABLE',
    assignedVictim: null,
    position: { ...DRONE_BASE },
  },
];

export const INITIAL_TEAMS: RescueTeam[] = [
  { id: 'R001', status: 'AVAILABLE', assignedVictim: null },
  { id: 'R002', status: 'AVAILABLE', assignedVictim: null },
];

export const INITIAL_KITS = 4;

export const INITIAL_ALERTS: Alert[] = [
  {
    id: 'alert-init',
    type: 'info',
    title: 'System Initialized',
    message: 'Synthetic flood scenario loaded for Green Valley. 5 victims, 2 drones, 2 rescue teams, 4 emergency kits. Awaiting analysis.',
    timestamp: new Date().toISOString(),
    severity: 'info',
  },
];

export const SAFETY_DISCLAIMER =
  'This is a synthetic disaster-response simulation. AI assessments are decision-support recommendations and are not medical diagnoses. Human responders must verify victim conditions before real-world action. Drone and rescue operations shown are simulated.';

export const VICTIM_ASSESSMENTS: Record<
  string,
  {
    outcome: 'VISUAL_RISK' | 'RESPONSIVE' | 'UNRESPONSIVE';
    observations: string[];
    conversation: { speaker: 'drone' | 'victim' | 'rescue' | 'ai'; text: string }[];
  }
> = {
  V001: {
    outcome: 'VISUAL_RISK',
    observations: [
      'Person lying down on rooftop',
      'No visible movement detected',
      'Surrounded by rising floodwater',
      'Abnormal posture observed',
      'Appears trapped by debris',
    ],
    conversation: [],
  },
  V002: {
    outcome: 'RESPONSIVE',
    observations: [
      'Person visible at second-floor window',
      'Appears conscious and alert',
      'Making hand signals toward drone',
    ],
    conversation: [
      { speaker: 'drone', text: 'Drone D001 approaching. Can you hear me? This is the Green Valley Emergency Response drone.' },
      { speaker: 'victim', text: 'Yes, I can hear you! I am trapped on the second floor. I have severe pain in my head and I cannot stand.' },
      { speaker: 'rescue', text: 'Are there other people with you?' },
      { speaker: 'victim', text: 'Yes, there are two other people with me. One is a child.' },
      { speaker: 'rescue', text: 'Do you have access to food or water?' },
      { speaker: 'victim', text: 'No, we have nothing. The water rose very fast.' },
      { speaker: 'rescue', text: 'Help is on the way. Stay near the window and keep talking to us.' },
      { speaker: 'ai', text: 'AI Commander: Extracted — reported severe symptoms, inability to stand, 3 people total including a child, no food/water, high immediate danger. Priority elevated to CRITICAL.' },
    ],
  },
  V003: {
    outcome: 'RESPONSIVE',
    observations: [
      'Person standing on elevated ground',
      'Appears conscious and mobile',
      'Waving at drone',
    ],
    conversation: [
      { speaker: 'drone', text: 'Drone D002 approaching. Can you hear me? This is the Green Valley Emergency Response drone.' },
      { speaker: 'victim', text: 'Yes, I can hear you. I am okay but I need food and water. I have been here since last night.' },
      { speaker: 'rescue', text: 'Are you injured?' },
      { speaker: 'victim', text: 'No injuries, just very hungry and thirsty.' },
      { speaker: 'rescue', text: 'How many people are with you?' },
      { speaker: 'victim', text: 'Just me. But the water is still rising around my area.' },
      { speaker: 'ai', text: 'AI Commander: Extracted — no injuries, mobile, 1 person, food/water needed, rising water risk. Priority set to HIGH.' },
    ],
  },
  V004: {
    outcome: 'RESPONSIVE',
    observations: [
      'Person sitting on higher ground',
      'Appears conscious',
      'Minor visible limp observed',
    ],
    conversation: [
      { speaker: 'drone', text: 'Drone D001 approaching. Can you hear me?' },
      { speaker: 'victim', text: 'Yes, I can hear you. I hurt my ankle but I can walk slowly.' },
      { speaker: 'rescue', text: 'Is anyone else with you?' },
      { speaker: 'victim', text: 'No, just me. I managed to get to higher ground.' },
      { speaker: 'ai', text: 'AI Commander: Extracted — minor ankle injury, mobile, 1 person, no immediate danger. Priority set to MEDIUM.' },
    ],
  },
  V005: {
    outcome: 'RESPONSIVE',
    observations: [
      'Person standing on a bridge',
      'Appears calm and uninjured',
      'No visible distress',
    ],
    conversation: [
      { speaker: 'drone', text: 'Drone D002 approaching. Can you hear me?' },
      { speaker: 'victim', text: 'Yes, I am fine. I am stranded on this bridge but the water has stopped rising here.' },
      { speaker: 'rescue', text: 'Do you need immediate assistance?' },
      { speaker: 'victim', text: 'Not urgently. I just need a way off this bridge eventually.' },
      { speaker: 'ai', text: 'AI Commander: Extracted — no injuries, mobile, 1 person, no immediate danger, low urgency. Priority set to LOW.' },
    ],
  },
};
