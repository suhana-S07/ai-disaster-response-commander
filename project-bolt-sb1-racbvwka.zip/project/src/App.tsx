import { useSimulation } from '@/hooks/useSimulation';
import { Header } from '@/components/Header';
import { StatusCards } from '@/components/StatusCards';
import { TabNav } from '@/components/TabNav';
import { DemoControl } from '@/components/DemoControl';
import { CommandCenter } from '@/components/tabs/CommandCenter';
import { DroneAssessment } from '@/components/tabs/DroneAssessment';
import { VictimCommunication } from '@/components/tabs/VictimCommunication';
import { AIAnalysis } from '@/components/tabs/AIAnalysis';
import { ResponsePlan } from '@/components/tabs/ResponsePlan';
import { LiveResponse } from '@/components/tabs/LiveResponse';
import { Replanning } from '@/components/tabs/Replanning';
import { DISASTER_INFO } from '@/data/scenario';

function App() {
  const sim = useSimulation();

  const availableResources =
    sim.drones.filter((d) => d.status !== 'OFFLINE').length +
    sim.teams.filter((t) => t.status === 'AVAILABLE').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Background gradient */}
      <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950/20 pointer-events-none" />
      <div className="fixed inset-0 opacity-30 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10">
        <Header status={sim.status} agentMode={sim.agentMode} />

        <main className="max-w-[1600px] mx-auto px-4 sm:px-6 py-4 space-y-4">
          <StatusCards
            disasterType={DISASTER_INFO.type}
            severity={DISASTER_INFO.severity}
            victimCount={sim.victims.length}
            availableResources={availableResources}
            emergencyKits={sim.kits}
            status={sim.status}
          />

          <DemoControl
            status={sim.status}
            onRunAnalysis={sim.runAnalysis}
            onGeneratePlan={sim.generatePlan}
            onApprovePlan={sim.approvePlan}
            onApproveReplan={sim.approveReplan}
            onReset={sim.reset}
          />

          <div className="border-b border-slate-700/50">
            <TabNav
              activeTab={sim.activeTab}
              onTabChange={sim.setActiveTab}
              hasReplan={sim.replan !== null || sim.status === 'REPLANNING'}
            />
          </div>

          <div className="pb-8">
            {sim.activeTab === 'command' && (
              <CommandCenter
                victims={sim.victims}
                drones={sim.drones}
                teams={sim.teams}
                alerts={sim.alerts}
                status={sim.status}
                scanProgress={sim.scanProgress}
              />
            )}
            {sim.activeTab === 'assessment' && (
              <DroneAssessment victims={sim.victims} drones={sim.drones} />
            )}
            {sim.activeTab === 'communication' && (
              <VictimCommunication victims={sim.victims} />
            )}
            {sim.activeTab === 'analysis' && (
              <AIAnalysis victims={sim.victims} agentMode={sim.agentMode} />
            )}
            {sim.activeTab === 'plan' && (
              <ResponsePlan
                plan={sim.plan}
                agentMode={sim.agentMode}
                onApprove={sim.approvePlan}
                showApprove={sim.status === 'AWAITING_APPROVAL'}
              />
            )}
            {sim.activeTab === 'live' && (
              <LiveResponse
                victims={sim.victims}
                drones={sim.drones}
                teams={sim.teams}
                logs={sim.logs}
                agentMode={sim.agentMode}
                rescueProgress={sim.rescueProgress}
              />
            )}
            {sim.activeTab === 'replanning' && (
              <Replanning
                replan={sim.replan}
                victims={sim.victims}
                drones={sim.drones}
                agentMode={sim.agentMode}
                onApprove={sim.approveReplan}
                showApprove={sim.status === 'AWAITING_REPLAN_APPROVAL'}
                status={sim.status}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
