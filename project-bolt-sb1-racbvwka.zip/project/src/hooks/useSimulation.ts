import { useState, useCallback, useRef } from 'react';
import type {
  Victim,
  Drone,
  RescueTeam,
  Alert,
  ResponsePlan,
  OperationStatus,
  AgentMode,
  SimulationLogEntry,
} from '@/types';
import {
  INITIAL_VICTIMS,
  INITIAL_DRONES,
  INITIAL_TEAMS,
  INITIAL_KITS,
  INITIAL_ALERTS,
  VICTIM_ASSESSMENTS,
} from '@/data/scenario';
import { assessVictim, generateResponsePlan, generateReplan } from '@/lib/aiCommander';

const uid = () => Math.random().toString(36).substring(2, 11);

function formatOnSiteLog(droneId: string | null, teamId: string | null, victimId: string): string {
  const parts: string[] = [];
  if (droneId) parts.push(`Drone ${droneId}`);
  if (teamId) parts.push(`Team ${teamId}`);
  if (parts.length === 0) return `${victimId} awaiting available resources.`;
  return `${parts.join(' and ')} on site for ${victimId}.`;
}

function formatProgressLog(droneId: string | null, teamId: string | null, victimId: string): string {
  if (!droneId && !teamId) return `${victimId}: Awaiting available rescue team.`;
  if (teamId) return `${victimId}: Rescue in progress. Team ${teamId} approaching victim.`;
  return `${victimId}: Rescue in progress. Drone ${droneId} monitoring.`;
}

export function useSimulation() {
  const [victims, setVictims] = useState<Victim[]>(INITIAL_VICTIMS);
  const [drones, setDrones] = useState<Drone[]>(INITIAL_DRONES);
  const [teams, setTeams] = useState<RescueTeam[]>(INITIAL_TEAMS);
  const [kits, setKits] = useState(INITIAL_KITS);
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [plan, setPlan] = useState<ResponsePlan | null>(null);
  const [replan, setReplan] = useState<{ plan: ResponsePlan; reason: string } | null>(null);
  const [status, setStatus] = useState<OperationStatus>('STANDBY');
  const [agentMode, setAgentMode] = useState<AgentMode>('STANDBY');
  const [logs, setLogs] = useState<SimulationLogEntry[]>([]);
  const [activeTab, setActiveTab] = useState('command');
  const [scanProgress, setScanProgress] = useState(0);
  const [rescueProgress, setRescueProgress] = useState(0);
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const addAlert = useCallback((alert: Omit<Alert, 'id' | 'timestamp'>) => {
    setAlerts((prev) => [
      { ...alert, id: uid(), timestamp: new Date().toISOString() },
      ...prev,
    ]);
  }, []);

  const addLog = useCallback((phase: string, message: string, mode: AgentMode) => {
    setLogs((prev) => [
      ...prev,
      { id: uid(), timestamp: new Date().toISOString(), phase, message, agentMode: mode },
    ]);
  }, []);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach((t) => clearTimeout(t));
    timersRef.current = [];
  }, []);

  const setMode = useCallback((mode: AgentMode) => {
    setAgentMode(mode);
  }, []);

  const runAnalysis = useCallback(() => {
    clearTimers();
    setMode('DEMO_SIMULATION');
    setStatus('ANALYZING');
    addLog('ANALYSIS', 'AI Commander initiating disaster analysis for Green Valley flood scenario.', 'DEMO_SIMULATION');
    addAlert({
      type: 'info',
      title: 'Analysis Started',
      message: 'AI Commander is analyzing the disaster situation and initiating drone scans.',
      severity: 'info',
    });

    const victimIds = ['V001', 'V002', 'V003', 'V004', 'V005'];
    let delay = 500;

    victimIds.forEach((vid, idx) => {
      const t1 = setTimeout(() => {
        setVictims((prev) =>
          prev.map((v) =>
            v.id === vid ? { ...v, status: 'SCANNING' } : v
          )
        );
        setDrones((prev) =>
          prev.map((d, di) =>
            di === idx % 2 ? { ...d, status: 'SCANNING', assignedVictim: vid } : d
          )
        );
        setScanProgress(Math.round(((idx + 1) / 5) * 100));
        addLog('SCAN', `Drone scanning ${vid} in Zone ${String.fromCharCode(65 + idx)}.`, 'DEMO_SIMULATION');
      }, delay);
      timersRef.current.push(t1);
      delay += 800;

      const t2 = setTimeout(() => {
        const assessment = VICTIM_ASSESSMENTS[vid];
        const victim = INITIAL_VICTIMS.find((v) => v.id === vid)!;
        const result = assessVictim({
          ...victim,
          assessmentOutcome: assessment.outcome,
          visualObservations: assessment.observations,
        });

        setVictims((prev) =>
          prev.map((v) =>
            v.id === vid
              ? {
                  ...v,
                  status: 'ASSESSED',
                  assessmentOutcome: assessment.outcome,
                  visualObservations: assessment.observations,
                  riskLevel: result.riskLevel,
                  priority: result.priority,
                  priorityReason: result.priorityReason,
                  recommendedAction: result.recommendedAction,
                  reportedSymptoms: result.reportedSymptoms,
                  canMove: result.canMove,
                  peopleCount: result.peopleCount,
                  immediateDanger: result.immediateDanger,
                  foodWaterNeeded: result.foodWaterNeeded,
                  conversation: assessment.conversation.map((c) => ({
                    ...c,
                    timestamp: new Date().toISOString(),
                  })),
                }
              : v
          )
        );

        if (assessment.outcome === 'VISUAL_RISK') {
          addAlert({
            type: 'high_visual_risk',
            title: 'HIGH VISUAL RISK',
            message: `${vid}: Person appears unresponsive in Zone ${String.fromCharCode(65 + idx)}. Visual indicators: ${assessment.observations.join(', ').toLowerCase()}. Human assessment required.`,
            severity: 'critical',
          });
          addLog('ALERT', `${vid} flagged as HIGH VISUAL RISK — unresponsive, trapped by floodwater.`, 'DEMO_SIMULATION');
        } else if (assessment.outcome === 'RESPONSIVE') {
          addAlert({
            type: 'communication_received',
            title: 'Communication Established',
            message: `${vid}: Two-way communication established. Victim is responsive. AI extracting response-relevant information.`,
            severity: 'info',
          });
          addLog('COMMS', `Two-way communication established with ${vid}. Extracting reported information.`, 'DEMO_SIMULATION');
        }
      }, delay);
      timersRef.current.push(t2);
      delay += 600;
    });

    const tFinal = setTimeout(() => {
      setDrones((prev) => prev.map((d) => ({ ...d, status: 'AVAILABLE' })));
      setScanProgress(100);
      setStatus('PLAN_READY');
      addLog('ANALYSIS', 'All victims assessed. AI Commander generating response plan.', 'DEMO_SIMULATION');
      addAlert({
        type: 'info',
        title: 'Analysis Complete',
        message: 'All 5 victims assessed. AI is generating the response plan with prioritization and resource assignments.',
        severity: 'info',
      });
    }, delay);
    timersRef.current.push(tFinal);
  }, [addAlert, addLog, clearTimers, setMode]);

  const generatePlan = useCallback(() => {
    setVictims((prevVictims) => {
      setDrones((prevDrones) => {
        setTeams((prevTeams) => {
          const dronesCopy = prevDrones.map((d) => ({ ...d, assignedVictim: null }));
          const teamsCopy = prevTeams.map((t) => ({ ...t, assignedVictim: null }));
          const newPlan = generateResponsePlan(prevVictims, dronesCopy, teamsCopy, kits, agentMode);

          setPlan(newPlan);

          const updatedDrones = dronesCopy.map((d) => {
            const item = newPlan.items.find((i) => i.droneId === d.id);
            return item ? { ...d, assignedVictim: item.victimId } : d;
          });
          const updatedTeams = teamsCopy.map((t) => {
            const item = newPlan.items.find((i) => i.teamId === t.id);
            return item ? { ...t, assignedVictim: item.victimId } : t;
          });

          setDrones(updatedDrones);
          setTeams(updatedTeams);

          let kitCount = kits;
          for (const item of newPlan.items) {
            if (item.kitAssigned) kitCount--;
          }
          setKits(kitCount);

          return updatedTeams;
        });
        return prevDrones;
      });
      return prevVictims;
    });

    setStatus('AWAITING_APPROVAL');
    addLog('PLAN', 'AI response plan generated. Awaiting human approval (Human-in-the-Loop).', agentMode);
    addAlert({
      type: 'human_approval_required',
      title: 'AI RESPONSE PLAN READY',
      message: 'The AI Commander has generated a response plan. Human approval is required before simulated execution.',
      severity: 'warning',
    });
  }, [addAlert, addLog, agentMode, kits]);

  const approvePlan = useCallback(() => {
    if (!plan) return;
    setStatus('SIMULATION_ACTIVE');
    addLog('APPROVAL', 'Response plan approved by human operator. Initiating simulated rescue execution.', agentMode);
    addAlert({
      type: 'info',
      title: 'Plan Approved',
      message: 'Human operator approved the response plan. Simulated rescue execution is now active.',
      severity: 'info',
    });

    setVictims((prev) =>
      prev.map((v) => {
        const item = plan.items.find((i) => i.victimId === v.id);
        if (item) {
          return {
            ...v,
            status: 'ASSIGNED',
            assignedDrone: item.droneId,
            assignedTeam: item.teamId,
            assignedKit: item.kitAssigned,
          };
        }
        return v;
      })
    );

    setDrones((prev) =>
      prev.map((d) => {
        const item = plan.items.find((i) => i.droneId === d.id);
        if (item) return { ...d, status: 'EN_ROUTE', assignedVictim: item.victimId };
        return d;
      })
    );

    setTeams((prev) =>
      prev.map((t) => {
        const item = plan.items.find((i) => i.teamId === t.id);
        if (item) return { ...t, status: 'EN_ROUTE', assignedVictim: item.victimId };
        return t;
      })
    );

    const priorityOrder = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
    const sortedItems = [...plan.items].sort((a, b) => priorityOrder.indexOf(a.priority) - priorityOrder.indexOf(b.priority));

    let delay = 1000;
    sortedItems.forEach((item) => {
      const t1 = setTimeout(() => {
        setDrones((prev) =>
          prev.map((d) => (d.id === item.droneId ? { ...d, status: 'ON_SITE' } : d))
        );
        setTeams((prev) =>
          prev.map((t) => (t.id === item.teamId ? { ...t, status: 'ON_SITE' } : t))
        );
        addLog('EXECUTION', formatOnSiteLog(item.droneId, item.teamId, item.victimId), agentMode);
      }, delay);
      timersRef.current.push(t1);
      delay += 1500;

      const t2 = setTimeout(() => {
        setVictims((prev) =>
          prev.map((v) =>
            v.id === item.victimId ? { ...v, rescueProgress: 50 } : v
          )
        );
        setRescueProgress(50);
        addLog('EXECUTION', formatProgressLog(item.droneId, item.teamId, item.victimId), agentMode);
      }, delay);
      timersRef.current.push(t2);
      delay += 1500;
    });

    const tFail = setTimeout(() => {
      triggerResourceFailure();
    }, delay + 500);
    timersRef.current.push(tFail);
  }, [plan, addAlert, addLog, agentMode]);

  const triggerResourceFailure = useCallback(() => {
    setStatus('REPLANNING');
    addAlert({
      type: 'resource_failure',
      title: 'RESOURCE FAILURE',
      message: 'D001 — OFFLINE. Drone has become unavailable. AI Commander detecting affected assignments and replanning.',
      severity: 'critical',
    });
    addLog('FAILURE', 'D001 became unavailable. AI Commander detecting impact on response plan.', agentMode);

    setDrones((prev) =>
      prev.map((d) =>
        d.id === 'D001' ? { ...d, status: 'OFFLINE', assignedVictim: null } : d
      )
    );

    setVictims((prev) =>
      prev.map((v) =>
        v.assignedDrone === 'D001' ? { ...v, assignedDrone: null } : v
      )
    );

    const t1 = setTimeout(() => {
      setVictims((currentVictims) => {
        setDrones((currentDrones) => {
          const result = generateReplan(
            currentVictims,
            currentDrones,
            teams,
            kits,
            'D001',
            agentMode
          );
          setReplan(result);
          setPlan(result.plan);

          const updatedDrones = currentDrones.map((d) => {
            const item = result.plan.items.find((i) => i.droneId === d.id);
            if (item && d.status !== 'OFFLINE') {
              return { ...d, status: 'EN_ROUTE', assignedVictim: item.victimId };
            }
            return d;
          });
          setDrones(updatedDrones);

          setVictims((victimsUpdate) =>
            victimsUpdate.map((v) => {
              const item = result.plan.items.find((i) => i.victimId === v.id);
              if (item) {
                return {
                  ...v,
                  assignedDrone: item.droneId,
                  assignedTeam: item.teamId,
                  assignedKit: item.kitAssigned,
                };
              }
              return v;
            })
          );

          return updatedDrones;
        });
        return currentVictims;
      });

      setStatus('AWAITING_REPLAN_APPROVAL');
      addAlert({
        type: 'replanning_required',
        title: 'AI REPLANNING COMPLETE',
        message: 'AI Commander has generated an updated response plan. Human approval required for modified assignments.',
        severity: 'warning',
      });
      addLog('REPLAN', 'AI replanning complete. Updated plan ready for human approval.', agentMode);
    }, 2000);
    timersRef.current.push(t1);
  }, [addAlert, addLog, agentMode, teams, kits]);

  const approveReplan = useCallback(() => {
    if (!replan) return;
    setStatus('SIMULATION_ACTIVE');
    addLog('APPROVAL', 'Updated response plan approved. Continuing simulated rescue execution.', agentMode);
    addAlert({
      type: 'info',
      title: 'Replan Approved',
      message: 'Human operator approved the updated response plan. Simulated rescue execution continues.',
      severity: 'info',
    });

    let delay = 1000;
    const remainingVictims = victims.filter((v) => v.status !== 'RESCUED' && v.rescueProgress < 100);
    const priorityOrder = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
    const sorted = [...remainingVictims].sort((a, b) => priorityOrder.indexOf(a.priority) - priorityOrder.indexOf(b.priority));

    sorted.forEach((v) => {
      const t1 = setTimeout(() => {
        setVictims((prev) =>
          prev.map((vv) => (vv.id === v.id ? { ...vv, rescueProgress: 75 } : vv))
        );
        setRescueProgress(75);
        addLog('EXECUTION', `${v.id}: Rescue continuing with reassigned resources.`, agentMode);
      }, delay);
      timersRef.current.push(t1);
      delay += 1200;

      const t2 = setTimeout(() => {
        setVictims((prev) =>
          prev.map((vv) => (vv.id === v.id ? { ...vv, rescueProgress: 100, status: 'RESCUED' } : vv))
        );
        setDrones((prev) =>
          prev.map((d) =>
            d.assignedVictim === v.id ? { ...d, status: 'AVAILABLE', assignedVictim: null } : d
          )
        );
        setTeams((prev) =>
          prev.map((t) =>
            t.assignedVictim === v.id ? { ...t, status: 'RETURNING', assignedVictim: null } : t
          )
        );
        addLog('EXECUTION', `${v.id}: Rescue complete. Victim extracted to safety.`, agentMode);
      }, delay);
      timersRef.current.push(t2);
      delay += 1000;
    });

    const tFinal = setTimeout(() => {
      setStatus('COMPLETED');
      setRescueProgress(100);
      setDrones((prev) => prev.map((d) => (d.status !== 'OFFLINE' ? { ...d, status: 'AVAILABLE' } : d)));
      setTeams((prev) => prev.map((t) => ({ ...t, status: 'AVAILABLE' })));
      addAlert({
        type: 'simulation_completed',
        title: 'SIMULATION COMPLETED',
        message: 'All victims have been rescued. Simulation complete. 5/5 victims extracted to safety.',
        severity: 'info',
      });
      addLog('COMPLETE', 'Simulation completed. All victims rescued.', agentMode);
    }, delay + 500);
    timersRef.current.push(tFinal);
  }, [replan, victims, addAlert, addLog, agentMode]);

  const reset = useCallback(() => {
    clearTimers();
    setVictims(INITIAL_VICTIMS);
    setDrones(INITIAL_DRONES);
    setTeams(INITIAL_TEAMS);
    setKits(INITIAL_KITS);
    setAlerts(INITIAL_ALERTS);
    setPlan(null);
    setReplan(null);
    setStatus('STANDBY');
    setAgentMode('STANDBY');
    setLogs([]);
    setScanProgress(0);
    setRescueProgress(0);
  }, [clearTimers]);

  return {
    victims,
    drones,
    teams,
    kits,
    alerts,
    plan,
    replan,
    status,
    agentMode,
    logs,
    activeTab,
    scanProgress,
    rescueProgress,
    setActiveTab,
    runAnalysis,
    generatePlan,
    approvePlan,
    approveReplan,
    triggerResourceFailure,
    reset,
  };
}
