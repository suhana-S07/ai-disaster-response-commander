import type {
  Victim,
  Drone,
  RescueTeam,
  ResponsePlan,
  ResponsePlanItem,
  PriorityLevel,
  RiskLevel,
  AgentMode,
} from '@/types';
import { DISASTER_INFO, VICTIM_ASSESSMENTS } from '@/data/scenario';

const VICTIM_ASSESSMENT_DATA = VICTIM_ASSESSMENTS;

export function assessVictim(victim: Victim): {
  riskLevel: RiskLevel;
  priority: PriorityLevel;
  priorityReason: string;
  recommendedAction: string;
  reportedSymptoms: string[];
  canMove: boolean;
  peopleCount: number;
  immediateDanger: string;
  foodWaterNeeded: boolean;
} {
  const assessment = VICTIM_ASSESSMENT_DATA[victim.id];
  if (!assessment) {
    return {
      riskLevel: 'LOW',
      priority: 'LOW',
      priorityReason: 'No assessment data available.',
      recommendedAction: 'Pending drone scan.',
      reportedSymptoms: [],
      canMove: true,
      peopleCount: 1,
      immediateDanger: '',
      foodWaterNeeded: false,
    };
  }

  let riskLevel: RiskLevel = 'LOW';
  let priority: PriorityLevel = 'LOW';
  let priorityReason = '';
  let recommendedAction = '';
  let reportedSymptoms: string[] = [];
  let canMove = true;
  let peopleCount = 1;
  let immediateDanger = '';
  let foodWaterNeeded = false;

  if (assessment.outcome === 'VISUAL_RISK') {
    riskLevel = 'CRITICAL';
    priority = 'CRITICAL';
    priorityReason = `Person appears unresponsive and is located in a high-risk flood zone. Visual indicators: ${assessment.observations.join(', ').toLowerCase()}.`;
    recommendedAction = 'Immediate rescue team dispatch required. Human assessment required — cannot medically diagnose condition.';
    canMove = false;
    immediateDanger = 'Trapped by floodwater and debris';
  } else if (assessment.outcome === 'RESPONSIVE') {
    const convText = assessment.conversation.map((c) => c.text).join(' ');
    reportedSymptoms = extractSymptoms(convText);
    canMove = !convText.toLowerCase().includes('cannot stand') && !convText.toLowerCase().includes('cannot walk');
    peopleCount = extractPeopleCount(convText);
    foodWaterNeeded = convText.toLowerCase().includes('food') || convText.toLowerCase().includes('water') || convText.toLowerCase().includes('hungry') || convText.toLowerCase().includes('thirsty');
    immediateDanger = convText.toLowerCase().includes('rising') ? 'Rising floodwater' : 'Flood isolation';

    if (victim.urgency >= 9 && (reportedSymptoms.length > 0 || !canMove)) {
      riskLevel = 'CRITICAL';
      priority = 'CRITICAL';
      priorityReason = `Victim reports severe symptoms and inability to stand. ${peopleCount} people present including a child. No food or water available.`;
      recommendedAction = 'Immediate rescue team dispatch with emergency kit. Priority rescue — multiple victims including child.';
    } else if (victim.urgency >= 6 && foodWaterNeeded) {
      riskLevel = 'HIGH';
      priority = 'HIGH';
      priorityReason = `Victim reports need for food and water. Rising water in area. ${peopleCount} person present.`;
      recommendedAction = 'Dispatch drone with emergency kit. Monitor water levels. Rescue team when available.';
    } else if (victim.urgency >= 5) {
      riskLevel = 'MODERATE';
      priority = 'MEDIUM';
      priorityReason = `Victim reports minor injury but is mobile and on higher ground. ${peopleCount} person present.`;
      recommendedAction = 'Schedule rescue team pickup. No immediate life-threatening danger.';
    } else {
      riskLevel = 'LOW';
      priority = 'LOW';
      priorityReason = `Victim is safe, mobile, and stranded but not in immediate danger. ${peopleCount} person present.`;
      recommendedAction = 'Low-priority evacuation when resources permit.';
    }
  } else if (assessment.outcome === 'UNRESPONSIVE') {
    riskLevel = 'CRITICAL';
    priority = 'CRITICAL';
    priorityReason = 'Victim is unresponsive. Drone attempted communication with no response. Human assessment required.';
    recommendedAction = 'Immediate rescue team dispatch. Highest priority. Cannot determine condition remotely.';
    canMove = false;
    immediateDanger = 'Unresponsive in flood zone';
  }

  return {
    riskLevel,
    priority,
    priorityReason,
    recommendedAction,
    reportedSymptoms,
    canMove,
    peopleCount,
    immediateDanger,
    foodWaterNeeded,
  };
}

function extractSymptoms(text: string): string[] {
  const symptoms: string[] = [];
  const lower = text.toLowerCase();
  if (lower.includes('severe pain') || lower.includes('head')) symptoms.push('severe head pain');
  if (lower.includes('cannot stand')) symptoms.push('cannot stand');
  if (lower.includes('cannot walk')) symptoms.push('cannot walk');
  if (lower.includes('ankle')) symptoms.push('ankle injury');
  if (lower.includes('injur')) symptoms.push('reported injury');
  return symptoms;
}

function extractPeopleCount(text: string): number {
  const lower = text.toLowerCase();
  if (lower.includes('two other people') || lower.includes('3 people') || lower.includes('three people')) return 3;
  if (lower.includes('child')) return 3;
  if (lower.includes('just me') || lower.includes('1 person') || lower.includes('one person')) return 1;
  return 1;
}

export function generateResponsePlan(
  victims: Victim[],
  drones: Drone[],
  teams: RescueTeam[],
  availableKits: number,
  agentMode: AgentMode
): ResponsePlan {
  const sortedVictims = [...victims].sort((a, b) => {
    const priorityOrder: Record<PriorityLevel, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  const availableDrones = drones.filter((d) => d.status === 'AVAILABLE' || d.status === 'SCANNING' || d.status === 'COMMUNICATING');
  const availableTeams = teams.filter((t) => t.status === 'AVAILABLE');
  let kitsLeft = availableKits;

  const items: ResponsePlanItem[] = [];

  for (const victim of sortedVictims) {
    if (victim.priority === 'LOW' && victim.status === 'RESCUED') continue;

    const drone = availableDrones.find((d) => !d.assignedVictim);
    const team = availableTeams.find((t) => !t.assignedVictim);
    const needsKit = victim.foodWaterNeeded || victim.priority === 'CRITICAL' || victim.priority === 'HIGH';
    const kitAssigned = needsKit && kitsLeft > 0;

    if (kitAssigned) kitsLeft--;

    let reason = '';
    let action = '';

    if (victim.priority === 'CRITICAL') {
      reason = `${victim.id} has critical response priority. ${victim.priorityReason}`;
      action = victim.assessmentOutcome === 'VISUAL_RISK'
        ? 'Dispatch drone for aerial monitoring and rescue team for immediate extraction. Human assessment required on site.'
        : 'Dispatch rescue team with emergency kit. Victim is responsive but in severe distress.';
    } else if (victim.priority === 'HIGH') {
      reason = `${victim.id} has high response priority. ${victim.priorityReason}`;
      action = 'Dispatch drone with emergency kit and rescue team for evacuation.';
    } else if (victim.priority === 'MEDIUM') {
      reason = `${victim.id} has medium response priority. ${victim.priorityReason}`;
      action = 'Schedule rescue team pickup when higher-priority rescues are underway.';
    } else {
      reason = `${victim.id} has low response priority. ${victim.priorityReason}`;
      action = 'Low-priority evacuation when resources permit.';
    }

    items.push({
      victimId: victim.id,
      droneId: drone ? drone.id : null,
      teamId: team ? team.id : null,
      kitAssigned,
      priority: victim.priority,
      reason,
      action,
    });

    if (drone) drone.assignedVictim = victim.id;
    if (team) team.assignedVictim = victim.id;
  }

  return {
    items,
    generatedBy: agentMode,
    timestamp: new Date().toISOString(),
  };
}

export function generateReplan(
  victims: Victim[],
  drones: Drone[],
  teams: RescueTeam[],
  availableKits: number,
  failedDroneId: string,
  agentMode: AgentMode
): { plan: ResponsePlan; reason: string } {
  const affectedVictim = victims.find((v) => v.assignedDrone === failedDroneId);

  const replacementDrone = drones.find(
    (d) => d.status === 'AVAILABLE' && !d.assignedVictim
  );

  let reason = '';
  if (affectedVictim && replacementDrone) {
    reason = `${failedDroneId} became unavailable; ${replacementDrone.id} is the nearest available simulated drone/resource. Reassigning ${replacementDrone.id} → ${affectedVictim.id}.`;
  } else if (affectedVictim && !replacementDrone) {
    const teamId = affectedVictim.assignedTeam;
    reason = `${failedDroneId} became unavailable and no replacement drone is available. ${affectedVictim.id} will rely on rescue team ${teamId ? teamId : '(pending)'} only. Drone monitoring suspended for this victim.`;
  } else {
    reason = `${failedDroneId} became unavailable. No affected assignments found.`;
  }

  const priorityOrder: Record<PriorityLevel, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
  const sortedVictims = [...victims].sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

  const items: ResponsePlanItem[] = sortedVictims.map((victim) => {
    let droneId = victim.assignedDrone;
    let teamId = victim.assignedTeam;
    let kitAssigned = victim.assignedKit;

    if (victim.id === affectedVictim?.id) {
      droneId = replacementDrone ? replacementDrone.id : null;
    }

    let itemReason = '';
    let itemAction = '';

    if (victim.id === affectedVictim?.id) {
      if (replacementDrone) {
        itemReason = `${failedDroneId} became unavailable; ${replacementDrone.id} reassigned to ${victim.id}. ${victim.priorityReason}`;
        itemAction = `Drone ${replacementDrone.id} and team ${teamId || 'pending'} dispatched for aerial monitoring and extraction.`;
      } else {
        itemReason = `${failedDroneId} became unavailable; no replacement drone available. ${victim.id} assigned to rescue team ${teamId || 'pending'} only. ${victim.priorityReason}`;
        itemAction = `Rescue team ${teamId || 'pending'} dispatched for immediate extraction. Drone monitoring unavailable — human assessment required on site.`;
      }
    } else {
      if (victim.priority === 'CRITICAL') {
        itemReason = `${victim.id} has critical response priority. ${victim.priorityReason}`;
        itemAction = victim.assessmentOutcome === 'VISUAL_RISK'
          ? 'Dispatch drone for aerial monitoring and rescue team for immediate extraction. Human assessment required on site.'
          : 'Dispatch rescue team with emergency kit. Victim is responsive but in severe distress.';
      } else if (victim.priority === 'HIGH') {
        itemReason = `${victim.id} has high response priority. ${victim.priorityReason}`;
        itemAction = 'Dispatch drone with emergency kit and rescue team for evacuation.';
      } else if (victim.priority === 'MEDIUM') {
        itemReason = `${victim.id} has medium response priority. ${victim.priorityReason}`;
        itemAction = 'Schedule rescue team pickup when higher-priority rescues are underway.';
      } else {
        itemReason = `${victim.id} has low response priority. ${victim.priorityReason}`;
        itemAction = 'Low-priority evacuation when resources permit.';
      }
    }

    return {
      victimId: victim.id,
      droneId,
      teamId,
      kitAssigned,
      priority: victim.priority,
      reason: itemReason,
      action: itemAction,
    };
  });

  return {
    plan: { items, generatedBy: agentMode, timestamp: new Date().toISOString() },
    reason,
  };
}


